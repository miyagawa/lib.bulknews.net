#!/usr/local/bin/perl

# CP932.TXT $B$r0J2<$N>l=j$+$iF~<j$7$F$*$/(B
# ftp://ftp.unicode.org/Public/MAPPINGS/VENDORS/MICSFT/WINDOWS/CP932.TXT
$CP932TXT = "CP932.TXT";

# 95$B!A(B114$B6h$r(B U+E000$B!A(B $B$N;dMQNN0h$K%^%C%T%s%0$9$k>l9g$O(B 1 $B$7$J$$>l9g$O(B 0
$private_use_area = 1;

($SJIS, $UNI, $COM, $FB) = (0 .. 3);

open(F, "$CP932TXT") or die;
$i = 0;
while (<F>) {
	if ($_ =~ /^#/) { next; }
	($sjis, $uni, $com) = split(/\t+/, $_);
	if ($uni =~ /^ +/) { next; }
	$uni = hex(substr($uni, 2, 4));
	$sjis = hex(substr($sjis, 2));
	chomp($com);
	$tbl[$i++] = [$sjis, $uni, $com, 0];
}
close(F);
$max = $i;

&quicksort(0, $max - 1);

for ($i = 0; $i < $max; $i++) {
	$num = 0;
	for ($j = 0; $j < 5; $j++) {
		if ($tbl[$i+$j][$UNI] == $tbl[$i+$j+1][$UNI]) {
			$tbl[$i+$j][$FB] = $tbl[$i+$j+1][$FB] = 3;
			$num++;
		} else {
			last;
		}
	}
	if ($num) {
		for ($k = 0; $k <= $num; $ k++) {
			for ($m = $k + 1; $m <= $num; $m++) {
				if ($tbl[$i+$k][$SJIS] > $tbl[$i+$m][$SJIS]) {
					($tbl[$i+$k], $tbl[$i+$m]) = ($tbl[$i+$m], $tbl[$i+$k]);
				}
			}
		}
	}
	$i += $num;
}

for ($i = 0; $i < $max; $i++) {
	$c1  = ($tbl[$i][$SJIS] >> 8) & 0xFF;
	$c2  = $tbl[$i][$SJIS] & 0xFF;
	$u   = $tbl[$i][$UNI];
	if ($u != $before) { $flag = 0; }

	if ($tbl[$i][$FB] == 3 && $flag == 0) {
		if ($c1 == 0x81) {
			$tbl[$i][$FB] = 0;
			$flag = 1;
		} elsif ($c1 == 0x87) {
			$tbl[$i][$FB] = 0;
			$flag = 1;
		} elsif (0xFA <= $c1) {
			$tbl[$i][$FB] = 0;
			$flag = 1;
		}
	}
	$before = $u;
}

print <<'END';
<code_set_name> "cp932"
<mb_cur_min> 1
<mb_cur_max> 2
<subchar> \x3F
CHARMAP
END

for ($i = 0; $i < $max; $i++) {
	$u   = $tbl[$i][$UNI];
	$c1  = ($tbl[$i][$SJIS] >> 8) & 0xFF;
	$c2  = $tbl[$i][$SJIS] & 0xFF;
	$fb  = $tbl[$i][$FB];
	$com = substr($tbl[$i][$COM], 1);

	if ($private_use_area) {
		$private_use_area = &make_private_area($before, $u);
	}
	if ($tbl[$i][$SJIS] <= 0xFF) {
		printf("<U%04X> \\x%02X |%d # %s\n", $u, $c2, $fb, $com);
	} else {
		printf("<U%04X> \\x%02X\\x%02X |%d # %s\n", $u, $c1, $c2, $fb, $com);
	}
	$before = $u;
}
print "END CHARMAP\n";

sub make_private_area {
	my ($before, $current) = @_;
	my ($c1, $c2, $u, $ret);

	$ret = 1;
	if ($before < 0xE000 && 0xF900 <= $current) {
		for ($c1 = 0xF0; $c1 <= 0xF9; $c1++) {
			for ($c2 = 0x40; $c2 <= 0xFC; $c2++) {
				if ($c2 == 0x7F) { next; }
				$u = ($c1 - 0xF0) * 188 + ($c2 - 0x40 - (0x7F<=$c2)) + 0xE000;
				printf("<U%04X> \\x%02X\\x%02X |0 # PRIVATE USE AREA\n", 
					$u, $c1, $c2);
			}
		}
		$ret = 0;
	}
	return $ret;
}

sub quicksort {
	my ($i, $j) = @_;
	my $pivot;
	my $pivotindex;
	my $k;

	$pivotindex = findpivot($i, $j);
	if ($pivotindex != 0) {
		$pivot = $tbl[$pivotindex][1];
		$k = partition($i, $j, $pivot);
		&quicksort($i, $k-1);
		&quicksort($k, $j);
	}
}

sub partition {
	my ($i, $j, $pivot) = @_;
	my ($l, $r) = ($i, $j);

	while ($l <= $r) {
		($tbl[$l], $tbl[$r]) = ($tbl[$r], $tbl[$l]);

		while ($tbl[$l][$UNI] < $pivot) {
			$l++;
		}
		while ($tbl[$r][$UNI] >= $pivot) {
			$r--;
		}
	}
	return $l;
}

sub findpivot {
	my($i, $j) = @_;
	my $firstkey;
	my $k;
	$firstkey = $tbl[$i][1];
	for ($k = $i + 1; $k <= $j; $k++) {
		if ($tbl[$k][$UNI] > $firstkey) {
			return $k;
		} elsif ($tbl[$k][$UNI] < $firstkey) {
			return $i;
		}
	}
	return 0;
}
