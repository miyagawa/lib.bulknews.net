package UNIVERSAL::extends;

use strict;
use vars qw($VERSION);
$VERSION = 0.01;

package UNIVERSAL;
no strict 'refs';

sub extends {
    my($child, @base) = @_;
    my $pkg = caller(0);
    die "extends() should be called with class." if ref $child;
    die "inheritor/caller mismatch: $child ne $pkg" if $child ne $pkg;
    eval <<BASE;
package $child;
use base qw(@base);
BASE
    ;
}

1;
__END__

=head1 NAME

UNIVERSAL::extends - syntactic sugar for base.pm

=head1 SYNOPSIS

  use UNIVERSAL::extends;

  package Dog;
  Dog->extends('Animal');
  # same as use base qw(Animal)

=head1 DESCRIPTION

UNIVERSAL::extends is a syntactic sugar of base.pm for Java programmer.

=head1 AUTHOR

Tatsuhiko Miyagawa E<lt>miyagawa@bulknews.netE<gt>

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

L<UNIVERSAL::exports>, L<Class::Fields>, L<Class::Virtual>

=cut
