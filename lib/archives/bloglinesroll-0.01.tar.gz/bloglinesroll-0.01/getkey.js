var pitem = new Number(-1);

function showAbout() {
  if(document.all){
    if (document.all("about").style.display == "block"){
      document.all("about").style.display = "none";
    }else{
      document.all("about").style.display = "block";
    }
  }else if(document.getElementById){
    if (document.getElementById("about").style.display == "block"){
      document.getElementById("about").style.display = "none";
    }else{
      document.getElementById("about").style.display = "block";
    }
  }
}



function showall() {
  for(var t = 0; t < items.length; t++){
    if(document.all){
      document.all("p" + items[t]).style.display = "block";
    }else if(document.getElementById){
      document.getElementById("p" + items[t]).style.display = "block";
    }
  }
}

function hideall() {
  for(var t = 0; t < items.length; t++){
    if(document.all){
      document.all("p" + items[t]).style.display = "none";
    }else if(document.getElementById){
      document.getElementById("p" + items[t]).style.display = "none";
    }
  }
}
function show(t, pitem){
  id = items[circle(pitem)];
  if(document.all){
      document.all(t + id).style.display = "block";
  }else if(document.getElementById){
      document.getElementById(t + id).style.display = "block";
  }
}

function showHead(t, pitem){
  id = items[circle(pitem)];
  if(document.all){
      document.all(t + id).style.color = "rgb(51, 85, 136)";
      document.all(t + id).style.fontWeight = "bold";
  }else if(document.getElementById){
      document.getElementById(t + id).style.color = "rgb(51, 85, 136)";
      document.getElementById(t + id).style.fontWeight = "bold";
  }
}



function hideHead(t, id){
  id = items[circle(pitem)];
  if(document.all){
      document.all(t + id).style.color = "#999";
      document.all(t + id).style.fontWeight = "normal";
  }else if(document.getElementById){
      document.getElementById(t + id).style.color = "#999";
      document.getElementById(t + id).style.fontWeight = "normal";
  }
}
function hide(t, id){
  id = items[circle(pitem)];
  if(document.all){
      document.all(t + id).style.display = "none";
  }else if(document.getElementById){
      document.getElementById(t + id).style.display = "none";
  }
}
function key_Press(e){
  //alert(getKEYCODE(e))
  branchGO( getKEYCODE(e) )
}

function getKEYCODE(e){
    if(document.layers)              return  e.which        //n4
    else if(document.all)            return  event.keyCode  //e4,e5,e6
    else if(document.getElementById) return  e.charCode     //n6,moz
}


function circle(p){
  if (p < 0) p = p + items.length;
  if (p > items.length -1 ) p = p - items.length;
  pitem = p;
  return p;
}
function branchGO(ky){
//  if (pitem > items.length -1 ) pitem = pitem - items.length;
// alert(pitem +" "+ items.length + " " + ky);
  switch(ky){
   case 100 :  // 'd'
     hide("p", pitem);
     hide("h", pitem); // remove sidelink
     items = items._exclude(circle(pitem)); 
     show("p", pitem);
     showHead("h", pitem);
     break;
   case 105 :  // 'i'
     show("h", pitem);
     break;
   case 111 :  // 'o'
     showall();
     break;
   case 109 :  // 'm'
     hideall();
     break;
   case 110 :  // 'n'
     hide("p", pitem);
     hideHead("h", pitem);
     pitem++;
     show("p", pitem);
     showHead("h", pitem);
     break;
   case 112 :  // 'p'
     hide("p", pitem);
     hideHead("h", pitem);
     pitem--;
     show("p", pitem);
     showHead("h", pitem);
     break;
  }
}

Array.prototype._exclude = function (idx) {
  var array = new Array;
  for (var i = 0; i < this.length; i++) {
    if (i != idx) { array.push(this[i]); }
  }
  return array;
}; 

function display(id) {
  hide('p', pitem);
  hideHead('h', pitem);
  show('p', id);
  showHead('h', id);
  pitem = id;
}

function main (){
  branchGO(110);
  self.focus();
  document.onkeypress = key_Press;
}

