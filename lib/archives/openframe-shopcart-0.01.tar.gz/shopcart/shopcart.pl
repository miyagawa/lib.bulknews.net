#!/usr/local/bin/perl
# $Id$
#
# Tatsuhiko Miyagawa <miyagawa@bulknews.net>
#

use strict;
use lib '../../lib';

use OpenFrame;
use OpenFrame::Server::HTTP;

my $config = OpenFrame::Config->new;
$config->setKey(
    SLOTS => [
	{
	    dispatch => 'Local',
	    name     => 'OpenFrame::Slot::Session',
	    config   => {
		default_session => {
		    application => {},
		    country     => 'UK',
		    language    => 'en',
		},
		directory => 'sessions',
	    },
	},
	{
	    dispatch => 'Local',
	    name     => 'OpenFrame::Slot::Dispatch',
	    config   => {
		installed_applications => [
		    {
			namespace => 'shopcart',
			uri       => '/',
			dispatch  => 'Local',
			name      => 'ShopCart::Application',
			config    => { },
		    },
		],
	    },
	},
	{
	    dispatch => 'Local',
	    name     => 'OpenFrame::Slot::Generator',
	    config   => {
		presentation => 'view',
	    },
	},
    ],
);

$config->setKey(DEBUG => 1);

my $port = 8000;
my $server = OpenFrame::Server::HTTP->new(port => $port);
print "Point your browser to http://localhost:$port/\n";
$server->handle;

__END__

=head1 NAME

shopcart.pl - A simple web-based shopping cart

=head1 DESCRIPTION

This Perl script contains a small and understandable web application
for OpenFrame that allows you to run shopping cart application.

This uses an C<OpenFrame::Server::HTTP> stand-alone HTTP server, and
sets up an C<OpenFrame::Config> object with various slots: one for
session support, a simple dispatch slot, and another slot which
generates output using the Template Toolkit.

Run the script and point your favourite web browser at
http://localhost:8000/

=head1 AUTHOR

Tatsuhiko Miyagawa <miyagawa@bulknews.net>

=head1 COPYRIGHT

This module is free software; you can redistribute it or modify it
under the same terms as Perl itself.
