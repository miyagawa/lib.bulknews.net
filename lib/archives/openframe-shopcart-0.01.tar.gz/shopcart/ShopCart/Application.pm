package ShopCart::Application;
# $Id$
#
# Tatsuhiko Miyagawa <miyagawa@bulknews.net>
#

use strict;
use base qw(OpenFrame::Application);

our $epoints = sub {
    my $args = shift;
    my $cmd = $args->{command};
    return $cmd !~ /^_/ && __PACKAGE__->can($cmd) ? $cmd : 'default';
};

use ShopCart::Product;

sub default {
    my($self, $session, $request, $config) = @_;
    my @products = ShopCart::Product->retrieve_all;
    $self->{products} = \@products;
    return 1;
}

sub detail {
    my($self, $session, $request, $config) = @_;
    my $product = ShopCart::Product->retrieve($request->arguments->{id});
    $self->{product} = $product;
    return 1;
}

sub add {
    my($self, $session, $request, $config) = @_;
    my $product = ShopCart::Product->retrieve($request->arguments->{id});
    $self->{cart} ||= {};
    $self->{cart}->{$product->id}++;
    $self->{product} = $product;
    return 1;
}

sub register {
    my($self, $session, $request, $config) = @_;
    my @products = ShopCart::Product->retrieve_all;
    $self->{products} = { map { ($_->id => $_) } @products };
    $self->_cleanup_cart;
    return 1;
}

sub modify {
    my($self, $session, $request, $config) = @_;
    $self->{cart}->{$request->arguments->{id}} = int $request->arguments->{amount};
    $self->_cleanup_cart;
    return 1;
}

sub empty {
    my($self, $session, $request, $config) = @_;
    $self->{cart} = {};
    return 1;
}

sub _cleanup_cart {
    my $self = shift;
    my %cart = map {
	$self->{cart}->{$_} ? ($_ => $self->{cart}->{$_}) : ();
    } keys %{$self->{cart}};
    $self->{cart} = \%cart;
}

1;


