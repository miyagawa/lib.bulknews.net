package ShopCart::Product;
# $Id$
#
# Tatsuhiko Miyagawa <miyagawa@bulknews.net>
#

use strict;

our %products = (
    1 => {
	name   => 'Programming Perl 3rd Edition',
	price  => '60.98',
	author => 'Larry Wall etc.',
    },
    2 => {
	name   => 'Object Oriented Perl',
	price  => '40.98',
	author => 'Damian Conway',
    },
    3 => {
	name   => 'Effective Perl',
	price  => '40.98',
	author => 'Joseph Hall',
    },
);

sub retrieve {
    my($class, $id) = @_;
    my $data = $products{$id} or die "no product for $id";
    bless { id => $id, %$data }, $class;
}

sub retrieve_all {
    my $class = shift;
    return map $class->retrieve($_), keys %products;
}

sub id     { shift->{id} }
sub name   { shift->{name} }
sub price  { shift->{price} }
sub author { shift->{author} }

1;
