package Image::HTML;

use strict;
use vars qw($VERSION @ISA @EXPORT_OK);
$VERSION = '0.01';

use Image::Magick;

require Exporter;
@ISA       = qw(Exporter);
@EXPORT_OK = qw(image2html);

sub image2html {
    my $file = shift;
    return __PACKAGE__->new($file)->html;
}

sub new {
    my $proto = shift;
    my $class = ref $proto || $proto;
    my $self = bless {
	img   => Image::Magick->new,
	table => undef,
    }, $class;
    $self->read(@_) if @_;
    $self;
}

sub read {
    my($self, $file) = @_;
    $self->{table} = '';	# init
    $self->{img}->Read($file);
    my($width, $height) = map { $self->{img}->Get($_) } qw(width height);

    for (my $y = 0; $y < $height; $y++) {
	$self->{table} .= q(<TABLE height="1" border="0" cellspacing="0" cellpadding="0">);
	$self->{table} .= qq(<TR height="1">\n);
	for (my $x = 0; $x < $width; $x++) {
	    my @rgb = (split /,/, $self->{img}->get("pixel[$x,$y]"))[0..2];
	    $self->{table} .= sprintf(q(<TD width="1" height="1" bgcolor="#%02x%02x%02x"></TD>), @rgb);
	}
	$self->{table} .= qq(</TR>\n</TABLE>\n);
    }
}

sub html {
    my $self = shift;
    $self->{table};
}

1;
__END__

=head1 NAME

Image::HTML - converts any image to HTML table

=head1 SYNOPSIS

  use Image::HTML;

  my $image = Image::HTML->new;
  $image->read($file);
  my $html = $image->html;

  # functional
  use Image::HTML qw(image2html);
  my $html = image2html('foo.gif');

=head1 DESCRIPTION

No images for web pages! Image::HTML converts B<ANY> images to HTML table.

=head1 AUTHOR

Original code by Hiroyuki Oyama <oyama@crayfish.co.jp> and Takefumi
Kimura <takefumi@takefumi.com>.

Maintained by Tatsuhiko Miyagawa <miyagawa@bulknews.net>.

=head1 SEE ALSO

L<Image::Magick>

=cut
