package Three;
use strict;

sub value { 3 }

1;
