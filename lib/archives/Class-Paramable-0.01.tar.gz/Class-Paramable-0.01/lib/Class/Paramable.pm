package Class::Paramable;

use strict;
use vars qw($VERSION);
$VERSION = '0.01';

sub new {
    my($proto, $fields) = @_;
    my($class) = ref $proto || $proto;

    $fields = {} unless defined $fields;

    # make a copy of $fields.
    bless {%$fields}, $class;
}

sub param {
    my $self = shift;

    # $obj->param(key => [ ]);
    if (@_ > 2) {
	$self->{$_[0]} = [ @_[1 .. $#_] ];
    }
    # $obj->param(key => val);
    elsif (@_ == 2) {
	$self->{$_[0]} = $_[1];
    }
    # $key = $obj->param(key);
    elsif (@_ == 1) {
	my $val = $self->{$_[0]};
	my @val;
	if (ref($val) eq 'ARRAY') {
	    @val = @{$val};
	}
	else {
	    @val = split /\0/, $val;
	}
	return wantarray ? @val : $val[0];
    }
    # @keys = $obj->param;
    else {
	return keys %{$self};
    }
}

1;
__END__

=head1 NAME

Class::Paramable - Prototype or mixin of param-able object

=head1 SYNOPSIS

  use Class::Paramable;

  my $obj  = Class::Paramable->new({ foo => 1, bar => 2 });

  my $foo  = $obj->param('foo'); # 1
  my @keys = sort $obj->param;   # ('bar', 'foo')
  $obj->param(foo => 'foo');     # set
  $obj->param(bar => 1, 2, 3);   # multiple value
  $obj->param(bar => [ 1, 2, 3 ]);   # same

  package MyObject;
  use base qw(Class::Paramable); # use as mixin

  sub new {
      bless { foo => 'bar' }, shift;
  }

  package main;
  my $o    = MyObj->new;
  my $foo  = $o->param('foo'); # bar
  my @keys = $o->param;        # ('foo')

=head1 DESCRIPTION

Class::Paramable is a prototype for paramable object. param() method
definition in Class::Paramable is quite like that of CGI.pm's. It can
work nicely with HTML::Template, HTML::FillInForm or something like
that, which accepts param()able instance.

This module can also be used as mixin for classes which implements
param() method.

=head1 NOTE

=over 4

=item *

If value contains "\0" char, param() method splits the value with
"\0". With this behaviour, this module can work nice with CGI.pm's
Vars() method (or ReadParse() function).

=item *

If you use this module as mixin, the object should be hash based.

=back

=head1 AUTHOR

Tatsuhiko Miyagawa E<lt>miyagawa@bulknews.netE<gt>

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

L<Class::Accessor>, L<Tie::StdHash>

=cut
