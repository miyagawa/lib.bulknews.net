# perl.rb: Langscan module for Perl
#
# Author:  Tatsuhiko Miyagawa <miyagawa@bulknews.net>
# License: GPL2
#

require 'langscan/_common'

module LangScan
  module Perl
    module_function

    def name
      "Perl"
    end

    def abbrev
      "perl"
    end

    def extnames
      [".pl", ".PL", ".pm", ".t" ] # XXX remove ".t"
    end

    PERLTOKENIZER_PATH = $LOAD_PATH.map {|path|
      File.join(path, "langscan/perl/tokenizer.pl")
    }.find {|path| File.file?(path) }
    raise LangScanError.new("tokenizer.pl not found") if PERLTOKENIZER_PATH.nil?

    def scan(input)
      # XXX how can I specify perl path?
      IO.popen("perl #{PERLTOKENIZER_PATH}", "r+") do |io|
        io.write(input)
        io.close_write()
        until (io.eof?)
          type    = io.readline.chomp.intern
          lineno  = io.readline.chomp.to_i
          byteno  = io.readline.chomp.to_i
          bodylen = io.readline.chomp.to_i
          text    = io.read(bodylen)
          if type.nil? or text.nil? or lineno.nil? or byteno.nil?
            raise LangScanError.new("Unexpected output from tokenizer.pl")
          end
          yield Fragment.new(type, text, lineno, byteno)
          io.read(1) # newline
        end
      end
    end
    
    LangScan.register(self)
  end
end



    
    
    
