package Date::Range::Month;

use strict;
use vars qw($VERSION);
$VERSION = 0.01;

use Date::Calc;
use Date::Simple;

require Date::Range;
use base qw(Date::Range);

sub new {
    my $class = shift;
    if (@_ == 2) {
	return $class->_new_from_ym(@_);
    } elsif (@_ == 1) {
	my $date = UNIVERSAL::isa($_[0], 'Date::Simple')
	    ? $_[0] : Date::Simple->new($_[0]);
	return $class->_new_from_ym($date->year, $date->month);
    } else {
	require Carp;
	Carp::croak("Date::Range::Month->new(): Bad parameters: @_");
    }
}

sub _new_from_ym {
    my($class, $year, $month) = @_;
    my $dim = Date::Calc::Days_in_Month($year, $month);
    return $class->SUPER::new(
	Date::Simple->new($year, $month, 1),
	Date::Simple->new($year, $month, $dim),
    );
}

sub year {
    my $self = shift;
    return $self->start->year;
}

sub month {
    my $self = shift;
    return $self->start->month;
}

sub prev {
    my $self = shift;
    return $self->_add_delta_ym(-1);
}

sub next {
    my $self = shift;
    return $self->_add_delta_ym(1);
}

sub _add_delta_ym {
    my($self, $delta) = @_;
    my $class = ref $self;
    my @ymd = Date::Calc::Add_Delta_YM($self->year, $self->month, 1, 0, $delta);
    return $class->_new_from_ym(@ymd[0, 1]);
}

1;
__END__

=head1 NAME

Date::Range::Month - Date::Range for a particular month

=head1 SYNOPSIS

  use Date::Range::Month;

  my $range = Date::Range::Month->new(2002, 10);

  # inherited from Date::Range
  my $start = $range->start; # for 2002-10-01
  my $end   = $range->end;   # for 2002-10-31

  my $year  = $range->year;  # 2002
  my $month = $range->month; # 10

  my $prev  = $range->prev;  # Date::Range::Month for 2002/09
  my $next  = $range->next;  # Date::Range::Month for 2002/11

=head1 DESCRIPTION

Date::Range::Month is a subclass of Date::Range, which additilnaly
provides month oriented constructor / methods to Date::Range.

=head1 METHODS

=over 4

=item new

  $range = Date::Range::Month->new($year, $month);
  $range = Date::Range::Month->new($date);

constructs new Date::Range::Month object. If Date::Simple object is
specified, it builds a new object baased on its year and month.

=item year, month

  $year  = $range->year;
  $month = $range->month;

returns year and/or month of the month.

=item prev, next

  $month = $range->prev;
  $month = $range->next;

returns previous and/or next month object. It merely returns B<new>
object, rather than modifying the original one.

=back

Other methods are inherited from Date::Range. See L<Date::Range> for details.

=head1 AUTHOR

Tatsuhiko Miyagawa E<lt>miyagawa@bulknews.netE<gt>

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

L<Date::Range>, L<Date::Simple>

=cut
