package Wattman::Sequence;
use strict;

use Wattman::Sequence::Start;
use Wattman::Sequence::End;
use Wattman::Sequence::Like;
use Wattman::Sequence::Unlike;
use Wattman::Sequence::Request;

use overload q("") => sub { shift->code };

sub new {
    my($class, $recorder, $r, $query) = @_;
    bless {
	recorder => $recorder,
	r        => $r,
	query    => $query,
    }, $class;
}

sub code {
    # XXX remove me
    my $self = shift;
    require Data::Dumper;
    local $Data::Dumper::Indent = 1;
    return Data::Dumper::Dumper $self;
}

1;
