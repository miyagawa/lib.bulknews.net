package Wattman::Recorder;
use strict;
use CGI;
use FileHandle;
use Getopt::Long;
use HTTP::Daemon;
use IO::String;
use LWP::UserAgent;
use URI::Escape qw(uri_unescape uri_escape);

use Wattman;
use Wattman::Sequence;

sub new {
    my $class = shift;
    my $self = bless { }, $class;
    $self->_parse_options(@_);
    $self->{ua} = LWP::UserAgent->new;
    return $self;
}

sub _parse_options {
    my $self = shift;
    local @ARGV = @_;
    $self->{port} = 8080;
    GetOptions($self, "port=i");
}

sub run {
    my $self = shift;
    my $daemon = HTTP::Daemon->new(
	LocalPort => $self->{port},
    ) or die $!;
    $self->display_info($daemon);
    while (my $c = $daemon->accept) {
	while (my $r = $c->get_request) {
	    $self->handle_request($r, $c);
	}
	$c->close;
    }
}

sub handle_request {
    my($self, $r, $c) = @_;
    unless ($r->uri->host eq 'localhost') {
	return $self->request($r, $c);
    }

    # administration
    my $query = CGI->new($r->uri->query);
    my $action = $query->param('action') || "main";
    eval { $self->$action($r, $c, $query); };
    warn $@ if $@;
}

sub main {
    my($self, $r, $c, $query) = @_;
    $self->display($c => "welcome to wattman!");
}

sub start {
    my($self, $r, $c, $query) = @_;
    if ($self->{scenario}) {
	$self->display($c => "scenario $self->{scenario} has already started.");
	return;
    }
    $self->{scenario} = $query->param('scenario');
    $self->{testfile} = FileHandle->new("> $self->{scenario}.t")
	or die "$self->{scenario}.t: $!";
    $self->{testfile}->autoflush(1);
    $self->append(Wattman::Sequence::Start->new($self, $r, $query));
    $self->display($c => "scenario $self->{scenario} started successfully.")
}

sub end {
    my($self, $r, $c, $query) = @_;
    $self->append(Wattman::Sequence::End->new($self, $r, $query));
    my $scenario = $self->{scenario};
    $self->{testfile} = undef;
    $self->{scenario} = undef;
    $self->display($c => "scenario $scenario ended successfully.");

}

sub like {
    my($self, $r, $c, $query) = @_;
    $self->append(Wattman::Sequence::Like->new($self, $r, $query));
    $self->display($c => "like test added successfully.");
}

sub unlike {
    my($self, $r, $c, $query) = @_;
    $self->append(Wattman::Sequence::Unlike->new($self, $r, $query));
    $self->display($c => "unlike test added successfully.");
}

sub request {
    my($self, $r, $c) = @_;
    my $response = $self->{ua}->simple_request($r);
    if ($self->{scenario} && $response->content_type =~ m!^text/html!) {
	$self->append(Wattman::Sequence::Request->new($self, $r));
    }
    $c->send_response($response);
}

sub doit {
    my($self, $r, $c) = @_;
    $c->send_response($self->{ua}->simple_request($r));
}

sub append {
    my($self, $sequence) = @_;
    return unless $self->{scenario};
    $self->{testfile}->print($sequence); # overload of Wattman::Sequence
}

sub display_info {
    my($self, $daemon) = @_;
    printf "Wattman proxy is working at %s\n", $daemon->url;
}

sub display {
    my($self, $c, $msg) = @_;
    my $content = $self->make_html($msg);
    $c->send_file(IO::String->new($content));
}

sub make_html {
    my($self, $msg) = @_;
    my $html = <<HTML;
<html><head><title>Wattman Manager</title></head>
<body>
<h1>Wattman Manager</h1>
<b>$msg</b><br>
HTML
    ;

    $html .= <<HTML if $self->{scenario};
<form action="/">
<input type="radio" name="action" value="like" checked>like
<input type="radio" name="action" value="unlike">unlike
<input type="text" name="regex" size="20"> <input type="submit" value="add test">
</form>
<form action="/">
<input type="hidden" name="action" value="end">
Scenario $self->{scenario} is running: <input type="submit" value="stop">
</form>
HTML
    ;

    $html .= <<HTML if !$self->{scenario};
<form action="/">
<input type="hidden" name="action" value="start">
Scenario <input type="text" name="scenario" size="10"> <input type="submit" value="start">
</form>
HTML
    ;

    $html .= <<HTML
<hr>
<div align="right">Wattman $Wattman::VERSION</div>
</body>
</html>
HTML
    ;
    return $html;
}

1;
