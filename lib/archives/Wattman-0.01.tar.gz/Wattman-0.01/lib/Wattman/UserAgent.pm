package Wattman::UserAgent;
use strict;
use base qw(LWP::UserAgent);
use HTTP::Cookies;

sub new {
    my $class = shift;
    my $self = $class->SUPER::new(@_);
    $self->cookie_jar(HTTP::Cookies->new);
    return $self;
}

sub request {
    my($self, $request, $arg, $size, $previous) = @_;
    my $response = $self->SUPER::request($request, $arg, $size, $previous);
    if ($response->is_redirect && $request->method eq 'POST') {
        # XXX: copy-and-paste from LWP::UserAgent

        # Make a copy of the request and initialize it with the new URI
        my $referral = $request->clone;

        # And then we update the URL based on the Location:-header.
        my($referral_uri) = $response->header('Location');
        {
            # Some servers erroneously return a relative URL for redirects,
            # so make it absolute if it not already is.
            local $URI::ABS_ALLOW_RELATIVE_SCHEME = 1;
            my $base = $response->base;
            $referral_uri = $HTTP::URI_CLASS->new($referral_uri, $base)
                            ->abs($base);
        }

        $referral->url($referral_uri);
        $referral->remove_header('Host', 'Cookie');

        # switch to GET
        $referral->method('GET');
        $referral->content('');
        $referral->remove_header('Content-Length');
        return $self->request($referral, $arg, $size, $response);
    }
    return $response;
}


1;
