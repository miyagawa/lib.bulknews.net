package Wattman::Sequence::Request;
use strict;
use base qw(Wattman::Sequence);

use Data::Dumper;

sub code {
    my $self = shift;
    local $Data::Dumper::Indent = 1;

    # remove Cookie: and Content-Length header (generated in run-time)
    $self->{r}->remove_header($_) for qw(Cookie Content-Length);

    my $req_code = Data::Dumper->Dump([ $self->{r} ], [qw(request)]);
    return <<CODE;
$req_code
\$response = \$agent->simple_request(\$request);
CODE
    ;
}

1;
