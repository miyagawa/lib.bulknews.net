package Wattman::Sequence::End;
use strict;
use base qw(Wattman::Sequence);

sub code {
    my $self = shift;
    return <<CODE;
# $self->{recorder}->{scenario}.t ends here
CODE
    ;
}

1;
