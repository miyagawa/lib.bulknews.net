package Wattman::Sequence::Unlike;
use strict;
use base qw(Wattman::Sequence);

sub code {
    my $self = shift;
    my $regex = $self->{query}->param('regex');
    return <<CODE;
unlike(\$response->content, qr/$regex/i);
CODE
    ;
}

1;
