package Wattman;

use strict;
use vars qw($VERSION);
$VERSION = 0.01;

1;
__END__

=head1 NAME

Wattman - Wepapp Automated Testing Manager

=head1 SYNOPSIS

  % wattman_proxy &

=head1 DESCRIPTION

C<Wattman> is a automated testing manager for web
applications. Wattman works as HTTP proxy server and generates C<.t>
files that reprodocues HTTP sessions, handy for regression testing
with Test::Harness and Test::More.

=head1 USAGE

=over 4

=item *

Run C<wattman_proxy> and set up your web-browser's proxy setting
to the URL displayed.

=item *

Open

  http://localhost/

in your browser, then you can view the Wattman Manager window.

=item *

Put scenario name in text field and click C<start> button. Open new
browser window and run your scenario there. If you want to check the
HTML displayed, type regex in textbox and select C<like> or C<unlike>.

For example, if you want to validate that C<error> is in your HTML, choose
C<like> and type C<error> in textbox, then hit C<add test>.

=item *

To finish your scenario, hit C<stop> button, then auto-generated test
is saved under current directory.

=back

=head1 SALESPOINT

There're some software very similar to C<Wattman>. Here's a summary of
differences.

=over 4

=item Apache::Recorder + HTTP::RecordedSession

C<Apache::Recorder> acts as mod_perl handler, and provides API for
C<MonkeyWrench> and C<HTTP::WebTest>, whilest C<Wattman> acts as HTTP
proxy and generates C<.t> files using C<LWP::UserAgent>, L<Test::More>
and C<Test::Harness>.

=item RoboWeb

C<RoboWeb> acts as HTTP proxy server and generates C<.t> files, so is
very similar to C<Wattman>. But currently C<RoboWeb> seems not
maintained anymore.

=back

=head1 AUTHOR

Tatsuhiko Miyagawa E<lt>miyagawa@bulknews.netE<gt>

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

L<LWP::UserAgent>, L<Test::More>, L<Test::Harness>

=cut
