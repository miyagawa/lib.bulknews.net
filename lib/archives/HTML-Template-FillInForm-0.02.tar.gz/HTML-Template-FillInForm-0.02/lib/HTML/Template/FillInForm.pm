package HTML::Template::FillInForm;

use strict;
use vars qw($VERSION);
$VERSION = '0.02';

use HTML::Template;
use HTML::FillInForm;
use base qw(HTML::Template);

sub output {
    my $self = shift;
    my $html = $self->SUPER::output();

    return HTML::FillInForm->new->fill(
	scalarref => \$html, fobject => $self->{options}{associate},
    );
}

1;
__END__

=head1 NAME

HTML::Template::FillInForm - Glues HTML::FillInForm to HTML::Template

=head1 SYNOPSIS

  use CGI;
  use HTML::Template::FillInForm;

  my $query = CGI->new;
  my $tmpl  = HTML::Template::FillInForm->new(
      filename => 'foo.tmpl',
      associate => $q,
  );

  print $query->header, $tmpl->output;

=head1 DESCRIPTION

HTML::Template::FillInForm glues HTML::FillInForm functionality to
HTML::Template. It is useful for redisplaying user submitted form
information, without any HTML::Template C<E<lt>TMPL_IFE<gt>> stuff in
your templates.

=head1 AUTHOR

Tatsuhiko Miyagawa E<lt>miyagawa@bulknews.netE<gt>

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

L<HTML::Template>, L<HTML::FillInForm>

=cut
