package Module::LikeJava;
use strict;

sub new { bless {}, shift }

sub fooAndBar { }

sub BarAndBAZ { }

1;
