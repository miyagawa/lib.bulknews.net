package YAML::Lite;

use strict;
use vars qw($VERSION);
$VERSION = '0.01';

require Exporter;
*import = \&Exporter::import;

our @EXPORT_OK = qw(LoadFile Load);

use Carp ();

sub LoadFile {
    my $file = shift;
    open my $fh, $file or Carp::croak("$file: $!");
    my $yaml = join '', <$fh>;
    Load($yaml);
}

sub Load {
    my $yaml = shift;
    my $hash = {};
    my $nested = $hash;
    my $wanted;
    my %backtrack = (0 => $hash);
    for (split /\n/, $yaml) {
        next if /^\#/ or /^\s*$/;
        if (/^(\s*)(-\s*)(.*?):\s+(.*?)\s*$/) {
            if ($wanted) {
                $backtrack{length($1)} = $nested = $wanted->[0]->{$wanted->[1]} = [];
                undef $wanted;
            } else {
                $nested = $backtrack{length($1)};
            }
            push @{$nested}, { $3 => _munge($4) };
            $nested = $nested->[-1];
            $backtrack{length($1.$2)} = $nested;
        }
        elsif (/^(\s*)-\s*(.*)$/) {
            if ($wanted) {
                $backtrack{length($1)} = $nested = $wanted->[0]->{$wanted->[1]} = [];
                undef $wanted;
            }
            push @{$nested}, _munge($2);
        }
        elsif (/^(\s*)(\S*?):()\s*$/) {
            _clear_track(\%backtrack, length($1));
            if ($backtrack{length($1)}) {
                $nested = $backtrack{length($1)};
            } else {
                warn "---";
                $nested = $nested->{$2};
            }
            use Data::Dumper;
            warn Dumper $2, $nested, \%backtrack;
            $wanted = [ $nested, $2 ];
        }
        elsif (/^(\s*)(.*?)\s*:\s+(.*?)\s*$/) {
            _clear_track(\%backtrack, length($1));
            if ($wanted) {
                $nested = $wanted->[0]->{$wanted->[1]} = {};
                $backtrack{length($1)} = $nested;
                undef $wanted;
            } else {
                $nested = $backtrack{length($1)};
            }
            $nested->{$2} = _munge($3);
        }
    }
    return $hash;
}

sub _munge {
    my $val = shift;
    $val =~ s/^"(.*)"$/$1/;
    $val;
}

sub _clear_track {
    my($bt, $len) = @_;
    my @del;
    for my $key (keys %$bt) {
        $key > $len and push @del, $key;
    }
    delete $bt->{$_} for @del;
}

1;
__END__

=head1 NAME

YAML::Lite - Liteweight version of YAML

=head1 SYNOPSIS

  use YAML::Lite;
  my $data = YAML::Lite::LoadFile($yaml_file);

=head1 DESCRIPTION

YAML::Lite is a lightweigth version of YAML.pm. It only supports
single level nest of hash / array, and doesn't support Dump. It
doens't give you a fancy diagnostic message neither.

The motivation of writing this module is YAML.pm eats some sort of
unexpected memory. I'd recommend to develop your app with YAML.pm and
switch to YAML::Lite when you deploy to production environment.

=head1 AUTHOR

Tatsuhiko Miyagawa E<lt>miyagawa@bulknews.netE<gt>

Brian Ingerson for YAML.pm and Spoon::Config, which is a base of this
module.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

L<YAML> L<Spoon>

=cut
