package Class::DBI::MultiKeys;

use strict;
use vars qw($VERSION);
$VERSION = '0.01';

use base qw(Class::DBI);
use Carp::Assert;

# XXX: Pasted from Class::DBI

use constant TRUE       => (1==1);
use constant FALSE      => !TRUE;
use constant SUCCESS    => TRUE;
use constant FAILURE    => FALSE;
use constant YES        => TRUE;
use constant NO         => FALSE;


# In perl < 5.6 exists() doesn't quite work the same on pseudohashes
# as on regular hashes.  In order to protect ourselves we define our own
# exists function.

use constant PERL_VERSION => $];
sub _safe_exists {
    my($hash, $key) = @_;

    # Because PERL_VERSION is constant this logic will
    # be optimized away in Perl >= 5.6 and reduce to a simple
    # statement.

    # Either its 5.6 or its a hash.  Either way exists() is
    # safe.
    if( PERL_VERSION >= 5.006 ) {
        return exists $hash->{$key};
    }
    else {
        # We can't use ref() since that won't work on objects.
        if( UNIVERSAL::isa($hash, 'HASH') ) {     # hash
            return exists $hash->{$key};
        }
        # Older than 5.6 and its a pseudohash.  exists() will always return 
        # true, so we use defined() instead as a cheap hack.
        else {
            return defined $hash->{$key};
        }
    }
}



sub create {
    my($proto, $data) = @_;
    my($class) = ref $proto || $proto;

    my $self = $class->_init;
    my @primary_col = $self->columns('Primary');

    $self->normalize_hash($data);

    # There shouldn't be more input than we have columns for.
    assert($self->columns >= keys %$data) if DEBUG;
    
    # Everything in %data should be a column.
    assert( !grep { !$self->is_column($_) } keys %$data ) if DEBUG;

    # You -must- have a table defined.
    assert( $self->table ) if DEBUG;

    # XXX: We need full primary keys set.
    if (my @missing = grep { !_safe_exists($data, $_) } @primary_col) {
	require Carp;
	Carp::croak sprintf <<CARP, join(', ', @missing);
$class needs full primary keys set. But we miss %s
CARP
    ;
    }

    # Look for values which can be objects.
    my $hasa_cols = $class->__hasa_columns || {};
    $class->normalize_hash($hasa_cols);

    # For each column which can be an object (ie. hasa() was set) see if
    # we were given an object and replace it with its id().
    while( my($col, $want_class) = each %$hasa_cols) {
        if( _safe_exists($data, $col) && ref $data->{$col} ) {
            my $obj = $data->{$col};
            unless( $obj->isa($want_class) ) {
                require Carp;
                Carp::croak(sprintf <<CARP, $obj->isa($want_class));
$class expects an object of class $want_class for $col.  Got %s.
CARP

            }

            $data->{$col} = $obj->id;
        }
    }

    eval {
        # Enter a new row into the database containing our object's
        # information.
        my $sth = $self->sql_MakeNewObj($self->table,
                                        join(', ', keys %$data),
                                        join(', ', ('?') x keys %$data)
                                       );
        $sth->execute(values %$data);
    };
    if($@) {
        $self->DBIwarn('New', 'MakeNewObj');
        return;
    }

    # Create our object by PKs because the database may have filled out
    # alot of default rows that we don't know about yet.
    $self = $class->retrieve(@{$data}{@primary_col});

    return $self;
}


#'#
__PACKAGE__->set_sql('commit', <<"", 'Main');
UPDATE %s
SET    %s
WHERE  %s

sub commit {
    my($self) = shift;

    my $table = $self->table;
    assert( defined $table ) if DEBUG;

    if( my @changed_cols = $self->is_changed ) {
        eval {
            my $sth = $self->sql_commit($table,
                                        join( ', ', map { "$_ = ?" } 
                                                    @changed_cols),
                                        join(' AND ', map { "$_ = ?" }
						 $self->columns('Primary')),
                                       );
            $sth->execute((map { $self->{$_} } @changed_cols), 
                          $self->id,
                         );
        };
        if($@) {
            $self->DBIwarn( join(', ', $self->id), 'commit' );
            return;
        }

        $self->{__Changed}  = {};
    }

    return SUCCESS;
}

#'#
sub rollback {
    my($self) = shift;
    my($class) = ref $self;

    # rollback() is useless if autocommit is on.
    if( $self->autocommit ) {
        require Carp;
        Carp::croak('rollback() used while autocommit is on');
    }

    # Shortcut if there are no changes to rollback.
    return SUCCESS unless $self->is_changed;

    # Retrieve myself from the database again.
    my $data;
    eval {
        my $sth = $self->sql_GetMe(join(', ', $self->is_changed),
                                   $self->table,
                                   join(' AND ', map { "$_ = ?" }
					    $self->columns('Primary')),
                                  );
        $sth->execute($self->id);
        $data = $sth->fetchrow_hashref;
        $sth->finish;
    };
    if ($@) {
        $self->DBIwarn(join(', ', $self->id), 'GetMe');
        return;
    }

    unless( defined $data ) {
        require Carp;
        Carp::carp("rollback failed for ".join(', ', $self->id)." of class $class.");
        return;
    }

    $self->normalize_hash($data);

    # Make sure what we got from the database is what was changed.
    assert( join('', sort keys %$data) eq
            join('', sort $self->is_changed) ) if DEBUG;

    # Throw away our changes.
    @{$self}{keys %$data} = values %$data;
    $self->{__Changed}    = {};

    return SUCCESS;
}





__PACKAGE__->set_sql('GetMe', <<"", 'Main');
SELECT %s
FROM   %s
WHERE  %s

sub retrieve {
    my($proto, @key) = @_;
    my($class) = ref $proto || $proto;

    my @primary_cols = $class->columns('Primary');
    my $data;
    eval {
        my $sth = $class->sql_GetMe(join(', ', $class->columns('Essential')),
                                    $class->table,
				    join(' AND ', map { "$_ = ?" }
					     @primary_cols),
                                   );
        $sth->execute(@key);
        $data = $sth->fetchrow_hashref;
        $sth->finish;
    };
    if ($@) {
        $class->DBIwarn(join(', ', @key), 'GetMe');
        return;
    }

    return unless defined $data;
    
    return $class->construct($data);
}
    

sub copy {
    my($self, @new_keys) = @_;

    my %data = map { ($_ => $self->get($_) ) } $self->columns;
    @data{$self->columns('Primary')} = @new_keys;
    
    return $self->create(\%data);
}


#'#
sub move {
    my($class, $old_obj, @new_keys) = @_;

    # Make sure the thing being moved and the class being moved to
    # are related.
    assert( $class->isa(ref $old_obj) || $old_obj->isa($class) ) if DEBUG;

    my @primary_col  = $old_obj->columns('Primary');
    my @columns      = $old_obj->columns;

    assert( "@primary_col" eq "@{ $class->columns('Primary') }" ) if DEBUG;
    # XXX Should probably check to see if all the columns
    # XXX are there.

    my %data = map { ($_ => $old_obj->get($_) ) } @columns;
    if ( @new_keys ) {
	@data{@primary_col} = @new_keys;
    }
    
    return $class->create(\%data);
}


__PACKAGE__->set_sql('DeleteMe', <<"", 'Main');
DELETE 
FROM    %s
WHERE   %s


sub delete {
    my($self) = shift;

    eval {
        my $sth = $self->sql_DeleteMe($self->table,
				      join(' AND ', map { "$_ = ?" }
					       $self->columns('Primary')),
				  );
        $sth->execute($self->id);
    };
    if($@) {
        $self->DBIwarn(join(', ', $self->id), 'Delete');
        return;
    }

    undef %$self;
    bless $self, 'Class::Deleted';

    return SUCCESS;
}


sub id {
    my($self) = shift;
    return map { $self->get($_) } $self->columns('Primary');
}


sub sequence {
    my $class = shift;
    require Carp;
    Carp::croak "Can't use sequence() in class inherited from " . __PACKAGE__;
}
    


1;
__END__

=head1 NAME

Class::DBI::MultiKeys - Multiple keys implementation of Class::DBI

=head1 SYNOPSIS

  package Film;
  use base qw(Class::DBI::MultiKeys);

  # Tell Class::DBI::MultiKeys a little about yourself.
  Film->table('Movies');
  Film->columns(Primary => qw( Title Director ));
  Film->columns(All     => qw( Title Director Rating NumExplodingSheep));

  Film->set_db('Main', 'dbi:mysql', 'me', 'noneofyourgoddamnedbusiness',
               {AutoCommit => 1});


  #-- Meanwhile, in a nearby piece of code! --#
  use Film;

  # Create a new film entry for Bad Taste
  $btaste = Film->create({ Title       => 'Bad Taste',
                           Director    => 'Peter Jackson',
                           Rating      => 'R',
                           NumExplodingSheep   => 1
                         });

  # Retrieve the 'Gone With The Wind' by Victor Flemming entry
  # from the database.
  my $gone = Film->retrieve('Gone With The Wind', 'Victor Fleming');

  # Shocking new footage found reveals bizarre Scarlet/sheep scene!
  $gone->NumExplodingSheep(5);
  $gone->Rating('NC-17');
  $gone->commit;

  # Grab the 'Bladerunner' entry.
  my $blrunner = Film->retrieve('Bladerunner', 'Ridley Scott');

  # Make a copy of 'Bladerunner' and create an entry of the director's
  # cut from it.
  my $blrunner_dc = $blrunner->copy("Bladerunner: Director's Cut", 'Ridley Scott');

  # Ishtar by Elaine May doesn't deserve an entry anymore.
  Film->retrieve('Ishtar', 'Elaine May')->delete;

=head1 DESCRIPTION

Ad-hoc implementation of multiple primary keys in Class::DBI.

=head1 CAVEATS

THIS IS ALPHA RELEASE.

Very simple rough cut, maybe many bugs inside. Most of the methods are
cut and pasted from its parent, Class::DBI. Thus less maintainability
here.

=head1 AUTHOR

Tatsuhiko Miyagawa <miyagawa@bulknews.net>

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

L<Class::DBI>

=cut
