package MT::Plugin::Jcode;

use MT::Template::Context;

MT::Template::Context->add_global_filter(jcode => sub {
    my($str, $code, $ctx) = @_;
    require Jcode;
    my $from = Jcode::getcode($str) || 'utf8';
    return eval { Jcode->new($str, $from)->$code() } || $str;
});

1;
