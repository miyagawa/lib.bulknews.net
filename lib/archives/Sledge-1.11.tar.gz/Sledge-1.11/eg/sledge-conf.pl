#!/usr/local/bin/perl
$ENV{SLEDGE_CONFIG_NAME} = '_test';
1;


