package DBIx::GeneratedKey::mysqlPP;
use strict;
use base qw(DBIx::GeneratedKey::mysql);

1;
