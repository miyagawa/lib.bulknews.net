package Apache::ToolBar::Command;

use strict;
use vars qw($VERSION);
$VERSION = 0.01;

require Apache::ToolBar;
use base qw(DynaLoader Apache::ToolBar);

use Apache::Constants qw(:response);
use Apache::ModuleConfig;
use Apache::Util;

__PACKAGE__->bootstrap($VERSION) if $ENV{MOD_PERL};

sub convert_query {
    my($class, $r) = @_;
    my $cfg = Apache::ModuleConfig->get($r) || {};
    my $command = $cfg->{ToolBarCommand} or return;
    my $query = $class->query($r);

    # registerd command?
    $query =~ s/^(\S+)\s+// or return;
    my $engine = $command->{$1} or return;
    $engine =~ s/%u/$class->escape_it($query)/eg;
    return $engine;
}


sub ToolBarCommand($$$$) {
    my($cfg, $parms, $arg1, $arg2) = @_;
    $cfg->{ToolBarCommand} ||= {};
    $cfg->{ToolBarCommand}->{$arg1} = $arg2;
}

1;
__END__

=head1 NAME

Apache::ToolBar::Command - More customizable toolbar for MSIE

=head1 SYNOPSIS

  # 1. As an Apache proxy
  Listen 8888
  <VirtualHost *:8888>
  PerlTransHandler +Apache::ToolBar::Command
  ToolBarCommand cpan http://search.cpan.org/search?mode=module&query=%u
  ToolBarCommand perldoc http://perldoc.com/cgi-bin/htsearch?words=%u&restrict=perl5.8.0
  ToolBarCommand google http://www.google.com/search?q=%u
  </VirtualHost>

  # 2. As a pseudo-MSN
  <Location /response.asp>
  PerlHandler +Apache::ToolBar
  ToolBarCommand cpan http://search.cpan.org/search?mode=module&query=%u
  # ...
  </Location>

=head1 DESCRIPTION

Apache::ToolBar::Coommand is a more customizable proxy/webapp to
change your browser's Location box to your favourite toolbar!

With C<ToolBarCommand> settings shown in L</"SYNOPSIS">, you type
C<cpan Apache-ToolBar> or C<google blah blah> in your browser's
Location: box, then you will be redirected to the page you wanna go
to!

See L<Apache::ToolBar> for how this module works.

=head1 AUTHOR

Tatsuhiko Miyagawa E<lt>miyagawa@bulknews.netE<gt>

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

L<Apache::ToolBar>

=cut
