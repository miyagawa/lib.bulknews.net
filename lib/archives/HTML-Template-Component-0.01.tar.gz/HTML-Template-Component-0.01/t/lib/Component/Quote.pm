package Component::Quote;
# use base 'HTML::Template::Component';

# this component doesn't use a template file, so it sets
# TEMPLATE_FILE to 0.
use constant TEMPLATE_FILE => 0;

sub output {
    my $text = shift;  # since TEMPLATE_FILE is 0, no template is
                       # passed in.

    # do the quoting (ripped from CGI.pm!)
    $text =~ s/&/&amp;/g;
    $text =~ s/\"/&quot;/g; #"
    $text =~ s/>/&gt;/g;
    $text =~ s/</&lt;/g;

    # and return the quoted text as output.
    return $text;
}

1;
