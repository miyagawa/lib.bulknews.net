package Component::Headline;
#use base 'HTML::Template::Component';

use constant TEMPLATE_FILE => 'headline.tmpl';

sub output {
    my $template = shift;
    my $body = shift;  # holds what was in the middle of tags
    my $args = shift;  # holds a hash ref of arguments in begin tag

    # break out size and color from $args text
    # these could actually just be passed as $template->param(%{$args});
    my $size = $args->{'size'};
    my $color = $args->{'color'};

    $template->param(
	SIZE => $size,
	COLOR => $color,
	TITLE => $body,
    );
     return $template->output();
}

1;

