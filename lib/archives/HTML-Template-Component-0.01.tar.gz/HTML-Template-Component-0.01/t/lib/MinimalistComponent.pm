package MinimalistComponent;           # declare the package name
#use base 'HTML::Template::Component';  # required to be a component

# declare the template file name.
use constant TEMPLATE_FILE => 'minimal_component.tmpl';

# the output() method gets called when the component is used
sub output {
    my $template = shift;
    return $template->output();
}

1;
