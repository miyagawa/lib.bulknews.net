package HTML::Template::Component;

use strict;
use vars qw($VERSION);
$VERSION = '0.01';

use Carp;
use HTML::Template;

sub import {
    my $class = shift;
    local $SIG{__WARN__} = sub {};
    my $orig = \&HTML::Template::new;
    *HTML::Template::new = sub {
	my $class = shift;
	my %args = @_;
	$args{filter} = \&_component_filter;
	return $class->$orig(%args);
    };
}

sub _component_filter {
    my $textref = shift;
    $$textref =~ s{<TMPL_COMP\s+((?:[^=]+=\S+\s*)+)>(.*?)</TMPL_COMP>}{
	my %attr = map {
	    my($key, $val) = split /=/;
	    $val =~ s/^'(.*)'$/$1/ or $val =~ s/^"(.*)"$/$1/;
	    lc($key), $val;
	} split /\s+/, $1;
	my $body = $2;

	my $component = delete $attr{name}
	    or Carp::croak 'component name missing';
	eval qq{require $component};
	die $@ if $@ && $@ !~ /Can't locate/; #';

	my @args;
	if (my $file = $component->TEMPLATE_FILE) {
	    my $opt = $component->can('TEMPLATE_OPTIONS') ?
		$component->TEMPLATE_OPTIONS : [];
	    my $template = HTML::Template->new(
		filename => $file, @$opt,
	    );
	    push @args, $template;
	}
	push @args, $body, \%attr;
	my $meth = \&{"$component\::output"};
	$meth->(@args);
    }ixegs;
}


1;
__END__

=head1 NAME

HTML::Template::Component - a component framework for HTML::Template

=head1 SYNOPSIS

  use HTML::Template::Component;

=head1 DESCRIPTION

See Message-ID: <Pine.LNX.4.33.0111191224370.4059-200000@localhost.localdomain>

=head1 AUTHOR

Original idea by Sam Tregar E<lt>sam@tregar.comE<gt> on HTML::Template
mailing list.

Maintained by Tatsuhiko Miyagawa E<lt>miyagawa@bulknews.netE<gt>

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

L<HTML::Template>

=cut
