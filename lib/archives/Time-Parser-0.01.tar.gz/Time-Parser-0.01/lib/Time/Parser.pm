package Time::Parser;

use strict;
use vars qw($VERSION $AUTOLOAD);
$VERSION = '0.01';

use Time::Object ();
use Time::ParseDate ();

sub TIME_OBJ () { 0 }	# constant

sub parse {
    my $class = shift;
    if (@_ == 3) {
	# $year, $month, $day
	return $class->real_parse(join('/',@_));
    } 

    if (@_ == 1) {
	return $_[0] =~ m/^\d+$/ 
	    ? Time::Object->new($_[0])
	    : $class->real_parse($_[0]);
    } else {
	# default
	return Time::Object->new;
    }
	
}

sub real_parse {
    my $class = shift;
    my $str = shift;
    return Time::Object->new(Time::ParseDate::parsedate($str));
}


1;
__END__

=head1 NAME

Time::Parser - Datetime class

=head1 SYNOPSIS

  use Time::Parser;
  
  $t = Time::Parser->parse('2001/2/3 12:24:11');
  $t = Time::Parser->parse('2001/1/11');
  $t = Time::Parser->parse(time);
  $t = Time::Parser->parse();	# same
  $t = Time::Parser->parse(@ymd);

  # $t is a Time::Object

=head1 DESCRIPTION

This class is a wrapping constructor for Time::Object. 

=head1 AUTHOR

Tatsuhiko Miyagawa <miyagawa@edge.co.jp>

=head1 SEE ALSO

perl(1), L<Time::Object>, L<Time::ParseDate>.

=cut
