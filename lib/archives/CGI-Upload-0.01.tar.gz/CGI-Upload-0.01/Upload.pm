package CGI::Upload;

use strict;
use vars qw($VERSION);
$VERSION = '0.01';

use Carp;
use File::Basename ();
use Mac::Macbinary;
use MIME::Types;
use HTTP::BrowserDetect;

use constant DEFAULT_TYPE	=> 'application/octet-stream';
use constant MACBINARY_TYPE	=> 'application/x-macbinary';

sub new {
    my $class = shift;
    my $self = bless { }, $class;
    $self->_init(@_);
    $self->_decode;
    return $self;
}

sub _init {
    my $self = shift;
    while (my ($key, $value) = splice(@_,0,2)) {
	$self->{$key} = $value;
    }
    return $self;
}

sub _decode {
    my $self = shift;
    
    my $param = $self->query->param($self->name) or Carp::croak "Can't fetch param";

    # Detect Client Operating System for basename()
    $self->platform(_get_platform($ENV{HTTP_USER_AGENT}));

    # Set filepath: must be string
    $self->filepath("$param");
    
    # Set Content-Type
    $self->content_type($self->query->uploadInfo($param)->{'Content-Type'} || DEFAULT_TYPE);

    my $handle = $self->query->upload($self->name) or Carp::croak "Can't fetch filehandle";

    my $data;
    if ($self->is_macbinary) {
	my $macbinary = new Mac::Macbinary($handle) or Carp::croak "Can't decode Macbinary: $!";
	$data = $macbinary->data;

	# Set Original Content-Type
	$self->content_type((MIME::Types::by_suffix($macbinary->header->name))[0] || DEFAULT_TYPE);
    } else {
	local($/) = undef;	# slurp
	$data = <$handle>;
    }

    # Set data
    $self->data($data);
}

sub is_macbinary { $_[0]->content_type eq MACBINARY_TYPE }

# Accessors

sub query { $_[0]->{query} }
sub name  { $_[0]->{name} }

sub filepath {
    my $self = shift;
    $self->{filepath} = shift if @_;
    $self->{filepath};
}

sub basename {
    my $self = shift;
    File::Basename::fileparse_set_fstype($self->platform);
    return File::Basename::basename($self->filepath);
}

sub platform {
    my $self = shift;
    $self->{platform} = shift if @_;
    $self->{platform};
}

sub content_type { 
    my $self = shift;
    $self->{content_type} = shift if @_;
    $self->{content_type};
}

sub data {
    my $self = shift;
    $self->{data} = shift if @_;
    $self->{data};
}

sub _get_platform($) {
    my $agent = shift;
    my $browser = new HTTP::BrowserDetect($agent);
    for ($browser->os_string) {
	/Mac/ &&	return 'MacOS';
	/Win/ &&	return 'MSWin32';
    }
    return undef; 	# for others
}
	
	



1;
__END__

=head1 NAME

CGI::Upload - Operation on CGI uploaded files.

=head1 SYNOPSIS

  use CGI::Upload;
  use CGI;

  $query = CGI->new;
  $upload = CGI::Upload->new(query => $query, name => 'uploaded_file');

  $filename = $upload->basename;
  $orig_filepath = $upload->filepath;
  $content_type = $upload->content_type;
  $data = $upload->data;  

=head1 DESCRIPTION

This module is used for an easy operation on CGI-upload files using
C<CGI> query instance and parameter name.

While Macinstosh IE browsers send their local files to Servers in
MacBinary format, this module can fetch correct data and Content-Type
by using Mac::Macbinary and MIME::Types.

Correct basename() of local filenames can be fetched by using
HTTP::BrowserDetect.

=head1 METHODS

=head2 Class Methods

=over 4

=item new( query => QUERY, name => NAME )

constructs C<CGI::Upload> object. C<CGI> query instance and name for
the file-upload field.

=back

=head2 Instance Methods

=over 4 

=item basename

returns a basename of file in local environment. 

=item filepath

returns an original filepath in local environment. Delimiters for
directories are not removed, so returned L<as is>. For example,
C<filepath> returns "C:\Windows\System\foo.dll" if the client uses
Windows OS.

=item content_type

returns Content-Type of uploaded file. If the file is uploaded with
Macintosh IE 4.5 and Content-Type sent as "application/x-macbinary",
C<content_type()> tries to fetch original Content-Type using its
suffix with C<MIME::Types>.

=item data

returns data range of the original file.

=back

=head1 REQUIREMENT

CGI, Mac::Macbinary, MIME::Types, HTTP::BrowserDetect.

=head1 AUTHOR

Tatsuhiko Miyagawa <miyagawa@edge.co.jp>

=head1 SEE ALSO

perl(1).

=cut
