package CAPS::On;

use base qw(Foo);

1;
