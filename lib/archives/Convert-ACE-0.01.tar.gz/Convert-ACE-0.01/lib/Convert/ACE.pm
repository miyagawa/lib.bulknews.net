package Convert::ACE;

use strict;
use vars qw($VERSION @ISA @EXPORT_OK);
$VERSION = '0.01';

# for functional way
require Exporter;
@ISA = qw(Exporter);
@EXPORT_OK = qw(to_race from_race to_lace from_lace);

use Convert::RACE;
use Convert::LACE;

sub new {
    my $proto = shift;
    bless {}, ref($proto) || $proto;
}

sub race_encode {
    my $self = shift;
    return Convert::RACE->new->encode(@_);
}

sub race_decode {
    my $self = shift;
    return Convert::RACE->new->decode(@_);
}

sub lace_encode {
    my $self = shift;
    return Convert::LACE->new->encode(@_);
}

sub lace_decode {
    my $self = shift;
    return Convert::LACE->new->decode(@_);
}

sub decode {
    my $self = shift;
    my ($string) = @_;
    
    # prefex tags are set in lexical variables
    my $race_prefix = Convert::RACE->prefix_tag;
    my $lace_prefix = Convert::LACE->prefix_tag;

    for ($string) {
	/^$race_prefix/ && return $self->race_decode($string);
	/^$lace_prefix/ && return $self->lace_decode($string);
    }

    # otherwise, returns as is
    return $string;
}


# for functional way
sub to_race	{ Convert::ACE->new->race_encode(@_); }
sub from_race	{ Convert::ACE->new->race_decode(@_); }
sub to_lace	{ Convert::ACE->new->lace_encode(@_); }
sub from_lace	{ Convert::ACE->new->lace_decode(@_); }


1;
__END__

=head1 NAME

Convert::ACE - Conversion between Unicode and ACE

=head1 SYNOPSIS

  # OO way
  use Convert::ACE;
  $converter = Convert::ACE->new;

  $race_encoded = $converter->race_encode($utf16str);
  $lace_encoded = $converter->lace_encode($utf16str);

  $orig = $converter->decode('bq--aewrcsy');	# RACE-decodes

  # functional way
  use Convert::ACE 'to_race';
  $race_encoded = to_race($utf16str);

=head1 DESCRIPTION

Convert::ACE is a class for common interface in some ACE
(ASCII-Compatible Encoding) encodings. Conversion algorithms are
implemented in Convert::RACE and Convert::LACE.

=head1 METHODS

Following methods are available. See L<Convert::RACE>,
L<Convert::LACE> for details.

=over 4

=item $converter = Convert::ACE->new

Constructs Convert::ACE instance.

=item $converter->race_encode($string)

Takes UTF-16 encoding and returns RACE-encoded strings such as 'bq--aewrcsy.'

=item $converter->race_decode($domain_name)

Takes 'bq--' prefixed string and returns original UTF-16 string.

=item $converter->lace_encode($string)

Takes UTF-16 encoding and returns LACE-encoded strings such as 'lq--auyons5t7teq'

=item $converter->lace_decode($domain_name)

Takes 'lq--' prefixed string and returns original UTF-16 string.

=item $converter->decode($domain_name)

Automatically decodes a domain name according to its prefix tag. If no
tag is available, returns the domain name as is.

=back

=head1 FUNCTIONS

Following functions are shortcuts for methods. Handy in functional
programmings. They are all in B<@EXPORT_OK> array. See L<Exporter> for
details.

=item to_race($string)

=item from_race($domain_name)

=item to_lace($string)

=item from_lace($domain_name)


=head1 EXAMPLES

  use Convert::ACE;
  use Unicode::String 'latin1';  

  $converter = Convert::ACE->new;

  eval {
      print $converter->lace_encode(latin1($latin_string)->utf16);
  }
  if ($@) {
      warn "Can't encode: $@";
  }    

=head1 TODO

To implement Convert::UTF6, Convert::DUDE, Convert::BRACE.

Implementations are welcome. Recommended API is the same as
Convert::RACE and Convert::LACE.

=head1 AUTHOR

Tatsuhiko Miyagawa <miyagawa@bulknews.net>

This library is free software; you can redistribute it and/or
modify it under the same terms as Perl itself.

=head1 ACKNOWLEDGEMENT

Some parts of this code are stolen from Nameprep tool by Paul Hoffman
<phoffman@imc.org> at http://www.imc.org/nameprep/

=head1 SEE ALSO

perl(1), http://www.i-d-n.net/, L<Unicode::String>, L<Convert::RACE>,
L<Convert::LACE>.

=cut
