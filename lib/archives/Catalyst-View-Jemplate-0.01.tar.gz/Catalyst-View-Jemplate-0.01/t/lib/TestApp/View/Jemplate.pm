package TestApp::View::Jemplate;
use base qw( Catalyst::View::Jemplate );

1;
