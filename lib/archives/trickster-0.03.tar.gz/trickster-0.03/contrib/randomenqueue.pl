#!/usr/local/bin/perl
# $Id: randomenqueue.pl,v 1.9 2002/12/18 15:07:26 miyagawa Exp $

use strict;

package TricksterLite;
use vars qw($Config);

my $config_path = $ENV{TRICKSTER_LITE_CONF} || "$ENV{HOME}/.trickster-lite.conf";
$Config = TricksterLite::Config->new($config_path);

use DirHandle;
use FileHandle;
use File::Find;
use Time::HiRes qw(usleep gettimeofday);

my $Debug = 0;
my $interval = 3_000_000;

my $base_dir = $Config->get('base_directory');

make_pid_file();

END { unlink "$base_dir/logs/randomenqueue.pid" }

warn "now loading media files ..." if $Debug;
my $media_files = load_media_files();

$SIG{HUP} = sub {
    warn "caught SIGHUP. reloading media files." if $Debug;
    $media_files = load_media_files();
};

while (1) {
    $media_files = load_media_files() unless @{$media_files};
    my @queue = queue_files_in("$base_dir/queue");
    unless (@queue) {
	warn "no queue found" if $Debug;
	my $media = choose_random($media_files);
	warn "choosed $media" if $Debug;
	enqueue_media($media);
    }
    usleep $interval;
}


sub make_pid_file {
    my $pid = FileHandle->new("> $base_dir/logs/randomenqueue.pid");
    $pid->print($$, "\n");
    $pid->close;
}

sub queue_files_in {
    my $dir = shift;
    my $dh  = DirHandle->new($dir) or die "$dir: $!";
    return grep !/^now_playing/ && -f "$dir/$_", $dh->read;
}

sub load_media_files {
    my $media_dir = $Config->get('media_directory');
    my @media;
    my $finder = sub { 
	push @media, $File::Find::name 
	    if -f $File::Find::name && /\.mp3$/;
    };
    find($finder, $media_dir);
    return \@media;
}

sub choose_random {
    my $media = shift;
    my $index = rand @$media;
    return splice(@$media, $index, 1);
}

sub enqueue_media {
    my $media = shift;
    my $base_dir = $Config->get('base_directory');
    my $timestamp = gettimeofday;
    my $fh = FileHandle->new("> $base_dir/queue/$timestamp") or die $!;
    $fh->print($media, "\n");
}

#--------------------------------------------------

package TricksterLite::Config;
use base qw(Data::Properties);
use FileHandle;

sub new {
    my($class, $path) = @_;
    my $self = $class->SUPER::new;
    $self->load(FileHandle->new($path));
    return $self;
}

BEGIN {
    *get = __PACKAGE__->can('get_property');	# alias
}
