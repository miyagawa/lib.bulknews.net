package HTML::Template::FillInForm;

use strict;
use vars qw($VERSION @ISA);
$VERSION = '0.01';

require HTML::Template;
@ISA = qw(HTML::Template);

use HTML::FillInForm;

=pod

=head1 NAME

HTML::Template::FillInForm - Decorator for HTML::Template / HTML::FillInForm

=head1 SYNOPSIS
  
  use CGI;
  use HTML::Template::FillInForm;

  $q = CGI->new;
  $tmpl = HTML::Template::FillInForm->new(filename => 'foo.tmpl',
					  associate => $q);

  print $q->header, $tmpl->output;

=head1 DESCRIPTION

This module is a decorator class for HTML::Template. It inherits from
HTML::Template and wraps output() method with HTML::FillInForm's
fill() method.

It is useful for redisplaying user submitted form information, without
any HTML::Template's <TMPL_IF> stuff in template files.

=head1 METHODS

This class inherits from HTML::Template. The only overriden method is
output(). It generates html contents with HTML::Template::output(),
and fills in the form with HTML::FillInForm.

=cut

sub output 
{
    my $self = shift;
    my $html = $self->SUPER::output();

    # HTML::Template associate can handle multiple objects.
    # HTML::FillInForm seems not.
    my %fdat = map { 
	my $obj = $_;
	map { 
	    my @v = $obj->param($_);
	    ($_ => scalar(@v) > 1 ? \@v : $v[0]);
	} $obj->param;
    } @{$self->{options}{associate}};
    return HTML::FillInForm->new->fill(scalarref => \$html, fdat => \%fdat);
}

=pod

=head1 AUTHOR

Tatsuhiko Miyagawa <miyagawa@bulknews.net>

This library is free software; you can redistribute it and/or
modify it under the same terms as Perl itself.

=head1 SEE ALSO

perl(1), L<HTML::Template>, L<HTML::FillInForm>, L<CGI>.

=cut

1;
