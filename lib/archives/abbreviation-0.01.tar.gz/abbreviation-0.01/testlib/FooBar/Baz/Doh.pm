package FooBar::Baz::Doh;

use base qw(Foo);

1;

