package FooBar::Baz;

use strict;
use base qw(Foo);

1;
