package Foo;

use strict;

sub new { bless {}, shift; }

1;
