package Log::Dispatch::Config;

use strict;
use vars qw($VERSION);
$VERSION = '0.05_02';

require Log::Dispatch;
use base qw(Log::Dispatch);
use fields qw(config ctime);

sub configure {
    my($class, $config) = @_;
    die "no config file or configurator supplied" unless $config;

    # default configurator: AppConfig
    unless (UNIVERSAL::isa($config, 'Log::Dispatch::Configurator')) {
	require Log::Dispatch::Configurator::AppConfig;
	$config = Log::Dispatch::Configurator::AppConfig->new($config);
    }

    no strict 'refs';
    my $instance = "$class\::_instance";
    $$instance = $config;
}

# backward compatibility
sub Log::Dispatch::instance {
    __PACKAGE__->instance;
}

sub instance {
    my $class = shift;

    no strict 'refs';
    my $instance = "$class\::_instance";
    unless (defined $$instance) {
	require Carp;
	Carp::croak("Log::Dispatch::Config->configure not yet called.");
    }

    if (UNIVERSAL::isa($$instance, 'Log::Dispatch::Config')) {
        # reload singleton on the fly
	if ($$instance->needs_reload) {
	    $$instance = $$instance->reload;
	}
    }
    else {
        # first time call: $_instance is L::D::Configurator::*
	$$instance = $class->create_instance($$instance);
    }
    return $$instance;
}

sub needs_reload {
    my $self = shift;
    return $self->{config}->needs_reload($self);
}

sub reload {
    my $self = shift;
    my $class = ref $self;
    return $class->create_instance($self->{config}->reload);
}

sub create_instance {
    my($class, $config) = @_;

    my $callback = $class->format_to_cb($config->global_format, 3);
    my %dispatchers;
    foreach my $disp ($config->dispatchers) {
        $dispatchers{$disp} = $class->config_dispatcher(
                $disp, $config->attrs($disp),
	    );
    }
    my %args;
    $args{callbacks} = $callback if defined $callback;
    my $instance = $class->new(%args);

    for my $dispname (keys %dispatchers) {
	my $logclass = delete $dispatchers{$dispname}->{class};
	$instance->add(
	    $logclass->new(
		name => $dispname,
		%{$dispatchers{$dispname}},
	    ),
	);
    }

    # config info
    $instance->{config} = $config;
    $instance->{ctime} = time;

    return $instance;
}

sub config_dispatcher {
    my($class, $disp, $var) = @_;

    my $dispclass = $var->{class}
        or die "class param missing for $disp";

    eval qq{require $dispclass};
    die $@ if $@ && $@ !~ /locate/;

    if (exists $var->{format}) {
        $var->{callbacks} = $class->format_to_cb(delete $var->{format}, 5);
    }
    return $var;
}

my %syn = (
    d => 'datetime',
    p => 'level',
    m => 'message',
    F => 'filename',
    L => 'line',
    P => 'package',
);

sub format_to_cb {
    my($class, $format, $stack) = @_;
    return undef unless defined $format;

    return sub {
	my %p = @_;
	@p{qw(package filename line)} = caller($stack);
	$p{datetime} = scalar localtime;
	my $log = $format;
	$log =~ s/%n/\n/g;
	$log =~ s{%([dpmFLP])}{
	    if (exists $syn{$1}) {
		$p{$syn{$1}};
	    } else {
		warn "unrecognized format: %$1";
		'';
	    }
	}eg;
	return $log;
    };
}

1;
__END__

=head1 NAME

Log::Dispatch::Config - Log4j for Perl

=head1 SYNOPSIS

  use Log::Dispatch::Config;
  Log::Dispatch::Config->configure('/path/to/config');

  my $dispatcher = Log::Dispatch::Config->instance;

  # or the same
  my $dispatcher = Log::Dispatch->instance;

  # or if you write your own config parser:
  use Log::Dispatch::Configurator::XMLSimple;

  my $config = Log::Dispatch::Configurator::XMLSimple->new('log.xml');
  Log::Dispatch::Config->configure($config);

=head1 DESCRIPTION

Log::Dispatch::Config is a subclass of Log::Dispatch and provides a
way to configure Log::Dispatch object with configulation file
(default, in AppConfig format). I mean, this is log4j for Perl, not
with all API compatibility though.

=head1 METHOD

This module has a class method C<configure> which parses config file
for later creation of the Log::Dispatch::Config singleton instance.
(Actual construction of the object is done in the first C<instance>
call).

So, what you should do is call C<configure> method once in somewhere
(like C<startup.pl> in mod_perl), then you can get configured
dispatcher instance via C<Log::Dispatch::Config-E<gt>instance>.

Formerly, C<configure> method declares C<instance> method in
Log::Dispatch namespace. Now it inherits from Log::Dispatch, so the
namespace pollution is not necessary. Currrent version still defines
one-liner shortcut:

  sub Log::Dispatch::instance { Log::Dispatch::Config->instance }

so still you can call C<Log::Dispatch-E<gt>instance>, if you prefer,
or for backward compatibility.

=head1 CONFIGURATION

Here is an example of the config file:

  dispatchers = file screen

  file.class = Log::Dispatch::File
  file.min_level = debug
  file.filename = /path/to/log
  file.mode = append
  file.format = [%d] [%p] %m at %F line %L%n

  screen.class = Log::Dispatch::Screen
  screen.min_level = info
  screen.stderr = 1
  screen.format = %m

In this version, config file is written in AppConfig format, see
L</"PLUGGABLE CONFIGURATOR"> for other config parsing scheme.

=head2 GLOBAL PARAMETERS

=over 4

=item dispatchers

  dispatchers = file screen

C<dispatchers> defines logger names, which will be splitted by spaces.
If this parameter is unset, no logging is done.

=item format

  format = [%d] [%p] %m at %F line %L%n

C<format> defines log format. Possible conversions format are

  %d	datetime string
  %p	priority (debug, info, warning ...)
  %m	message string
  %F	filename
  %L	line number
  %P	package
  %n    newline (\n)

C<format> defined here would apply to all the log messages to
dispatchers. This parameter is B<optional>.

=back

=head2 PARAMETERS FOR EACH DISPATCHER

Parameters for each dispatcher should be prefixed with "name.", where
"name" is the name of each one, defined in global C<dispatchers>
parameter.

=over 4

=item class

  screen.class = Log::Dispatch::Screen

C<class> defines class name of Log::Dispatch subclasses. This
parameter is B<essential>.

=item format

  screen.format = -- %m --

C<format> defines log format which would be applied only to the
dispatcher. Note that if you define global C<format> also, C<%m> is
double formated (first global one, next each dispatcher one). This
parameter is B<optional>.

=item (others)

  screen.min_level = info
  screen.stderr = 1

Other parameters would be passed to the each dispatcher
construction. See Log::Dispatch::* manpage for the details.

=back

=head1 SINGLETON

Declared C<instance> method would make C<Log::Dispatch::Config> class
singleton, so multiple calls of C<instance> will all result in
returning same object.

  my $one = Log::Dispatch::Config->instance;
  my $two = Log::Dispatch::Config->instance; # same as $one

See GoF Design Pattern book for Singleton Pattern.

But in practice, in persistent environment like mod_perl, Singleton
instance is not so useful. Log::Dispatch::Config defines C<instance>
method so that the object reloads itself when configuration file is
modified since its last object creation time.

=head1 PLUGGABLE CONFIGURATOR

If you pass filename to C<configure()> method call, this module
handles the config file with AppConfig. You can change config parsing
scheme by passing another pluggable configurator object.

Here is a way to declare new configurator class. The example below is
hardwired version equivalent to the one above in L</"CONFIGURATION">.

=over 4

=item *

Inherit from Log::Dispatch::Configurator. Stub C<new> constructor is
inherited, but you can roll your own with it.

  package Log::Dispatch::Configurator::Hardwired;
  use base qw(Log::Dispatch::Configurator);

  sub new {
      bless {}, shift;
  }

=item *

Implement three required object methods C<global_format>,
C<dispatchers>, C<attrs>.

C<global_format> should return format string used in global
parameters.

  sub global_format {
      my $self = shift;
      return undef;
  }

C<dispatchers> should return list of names of dispatchers.

  sub dispatchers {
      my $self = shift;
      return 'file', 'screen';
  }

C<attrs> should accept name of dispatcher, and return hash reference
of parameters for the dispatcher.

  sub attrs {
      my($self, $name) = @_;
      if ($name eq 'file') {
          return {
              class     => 'Log::Dispatch::File',
              min_level => 'debug',
              filename  => '/path/to/log',
              mode      => 'append',
              'format'  => '[%d] [%p] %m at %F line %L%n',
          };
      } elsif ($name eq 'screen') {
          return {
	      class     => 'Log::Dispatch::Screen',
	      min_level => 'info',
	      stderr    => 1,
	      'format'  => '%m',
	  };
      }
  }

=item *

Implement optional C<needs_reload> and C<reload>
method. C<needs_reload> should return boolean value if the object is
stale and needs reloading itself.

Stub confif file mtime based C<needs_reload> method is declared in
Log::Dispatch::Configurator as below, so if your config class is based
on filesystem files, you do not need to reimplement this.

  sub needs_reload {
      my($self, $obj) = @_;
      return $obj->{ctime} < (stat($self->{file}))[9];
  }

C<reload> method is called when C<needs_reload> returns
true. Typically you should place configuration parsing again on
C<reload> method, so Log::Dispatch::Configurator again declares stub
C<reload> method that clones your object.

  sub reload {
      my $self = shift;
      my $class = ref $self;
      return $class->new($self->{file});
  }

=item *

Thats all. Now you can plug your own configurator (Hardwired) into
Log::Dispatch::Config. What you should do is to pass configurator
object to C<config()> method call instead of config file name.

  use Log::Dispatch;
  use Log::Dispatch::Configurator::Hardwired;

  my $config = Log::Dispatch::Configurator::Hardwired->new;
  Log::Dispatch::Config->confifure($config);

=back

=head1 TODO

=over 4

=item *

LogLevel configuration depending on caller package like log4j?

=item *

Allows stack level configuration for caller.

=item *

Date/time format configuration

=back

=head1 AUTHOR

Tatsuhiko Miyagawa E<lt>miyagawa@bulknews.netE<gt> with much help from
Matt Sergeant E<lt>matt@sergeant.orgE<gt>.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

L<Log::Dispatch>, L<AppConfig>

=cut
