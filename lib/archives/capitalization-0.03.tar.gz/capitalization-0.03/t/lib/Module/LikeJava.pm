package Module::LikeJava;
use strict;

sub new { bless {}, shift }

sub fooAndBar { }

sub BarAndBAZ { }

sub _Bar { }

sub FOO { }

sub FOObar { }

1;
