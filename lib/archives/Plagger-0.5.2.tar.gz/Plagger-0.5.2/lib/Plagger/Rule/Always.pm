package Plagger::Rule::Always;
use base qw( Plagger::Rule );

sub dispatch { 1 }

1;
