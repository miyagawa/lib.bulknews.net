package My::Session;

use strict;
use base qw(Apache::Session::File Apache::Session::Paramable);

sub new {
    my($class, $id) = @_;
    $class->SUPER::new($id, {
	Directory => 'testdb',
	LockDirectory => 'testdb/lock'
    });
}

1;
