package Apache::Session::Paramable;

use strict;
use vars qw($VERSION);
$VERSION = '0.01';

# override globally
sub import {
    no strict 'refs';
    my $class = shift;
    my %param = map { $_ => 1 } @_;
    if ($param{global}) {
	*{"Apache::Session::".$_} = \&$_ for (qw(new param remove _session_id));
    }
}

sub new {
    my($class, $sid, $attr_ref) = @_; # $class is inherited one, not me
    my %session;
    my $self = tie %session, $class, $sid, $attr_ref;
    return $self;
}

sub param {
    my $self = shift;
    if (@_ == 0) {
	# XXX Hacked from Apache::Session implementation
	keys %{$self->{data}};
    }
    elsif (@_ == 1) {
	$self->FETCH(@_);
    }
    else {
	$self->STORE(@_);
    }
}

sub remove {
    my($self, $key) = @_;
    $self->DELETE($key);
}

sub _session_id {
    my $self = shift;
    return $self->FETCH('_session_id');
}

1;
__END__

=head1 NAME

Apache::Session::Paramable - adds param method to Apache::Session subclasses

=head1 SYNOPSIS

  # in your own session class
  package My::Session;
  use base qw(Apache::Session::MySQL Apache::Session::Paramable);

  # in a client code
  package main;

  # make a fresh session
  my $session = My::Session->new(undef, \%attr);

  # stick some stuff in it
  $session->param(visa_number => "1234 5678 9876 5432");

  # get the sessoin id for later use
  my $id = $session->_session_id;

  # ... time passes ...
  my $session = My::Session->new($id, \%attr);

  my $visa_number = $session->param('visa_number');

  # remove the value from session
  $session->remove('visa_number');


=head1 DESCRIPTION

Apache::Session::Paramable is a mix-in for Apache::Session, providing
object-oriented interface to its subclasses. param() method is useful
when used with HTML::Template.

=head1 METHODS

=over 4

=item new

  my $session = $class->new($id, \%attr);

constructs the instance of Apache::Session subclass. Magical tie() is
dne internally in C<new()> method. C<%attr> is an hash for
subclass-dependent attributes. See the document of subclasses for its
detail.

=item param

  @paramlist = $session->param;
  $value = $session->param($key);
  $session->param($key => $value);

set/get the variables stored in the session. Without any arguments,
returns the list of the key ("keys") stored in the session, including
"_session_id".

=item remove

  $session->remove($key);

removes the variable from the session. Interface for Apache::Session::DELETE().

=item _session_id

  my $sid = $session->_session_id;

gets the current session id.

=back

=head1 EXAMPLE

=head2 nice combination with HTML::Template

  my $q = CGI->new;
  my $sid = $q->cookie('sid');

  my $session = My::Session->new($sid, \%attr);
  my $template = HTML::Template->new(
      filename => 'session.html',
      associate => [ $q, $session ],
  );

  print $q->header, $template->output;

=head2 Override Globally

  # if you don't like inheritance
  # make all Apache::Session subclasses be paramable
  use Apache::Session::Paramable 'global';
  my $session = Apache::Session::MySQL->new($id, \%attr);

  # the rest is the same as above

=head2 Efective Subclassing

  package My::Session;
  use base qw(Apache::Session::MySQL Apache::Session::Paramable);

  # set attribute data 
  # use Class::Data::Inheritable for more flexible configuration / subclassing
  my %attr = (
      DataSource => 'dbi:mysql:sessions',
      UserName   => 'user',
      Password   => 'foobar',
      LockDataSource => 'dbi:mysql:sessions',
      LockUserName   => 'user',
      LockPassword   => 'foobar',
  );

  sub new {
      my($class, $id) = @_;
      my $self = $class->SUPER::new($id, \%attr);
      # store the timestamp
      $self->param(_timestamp => time);
      # force update
      $self->make_modified;
      # etc, etc.
  }

  # alias for new
  sub create {
      my $class = shift;
      $class->new(undef, \%attr);
  }


=head1 AUTHOR

Tatsuhiko Miyagawa <miyagawa@bulknews.net>

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

L<Apache::Session>, L<HTML::Template>

=cut
