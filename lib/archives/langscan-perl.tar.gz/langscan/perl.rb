# perl.rb: Langscan module for Perl
#
# Author:  Tatsuhiko Miyagawa <miyagawa@cpan.org>
# License: GPL2
#

require 'langscan/_common'

module LangScan
  module Perl
    def name
      "Perl"
    end
    module_function :name

    def abbrev
      "perl"
    end
    module_function :abbrev

    def extnames
      [".pl", ".pm"] # how can I override this on user-side?
    end
    module_function :extnames

    PERLTOKENIZER_PATH = $LOAD_PATH.map {|path|
      File.join(path, "langscan/perl/tokenizer.pl")
    }.find {|path| File.file?(path) }
    raise LangScanError.new("tokenizer.pl not found") if PERLTOKENIZER_PATH.nil?

    def scan(input)
      IO.popen("perl #{PERLTOKENIZER_PATH}", "r+") do |io|
        io.write(input)
        io.close_write()
        io.each_line {|line|
          # without doubt, I prefer everything done on the Perl side.
          type, text, lineno, byteno = line.split("\t")
          if type.nil? or text.nil? or lineno.nil? or byteno.nil?
            raise LangScanError.new("Unexpected output from tokenizer.pl")
          end
          text.gsub!(/\\n/, "\n")
          text.gsub!(/\\t/, "\t")
          text.gsub!(/\\\\/, "\\")
          yield Fragment.new(type, text, lineno.to_i, byteno.to_i)
        }
      end
    end
    module_function :scan
    
    LangScan.register(self)
  end
end



    
    
    
