use strict;
use PPI::Tokenizer;

my $code = join '', <>;
my $tokenizer = PPI::Tokenizer->new(\$code);

our(%TokenMap, %ReservedWords, %BuitinFunctions);
our $parsed = '';

while (my $token = $tokenizer->get_token) {
    dump_element($token);
}

sub dump_element {
    my $element = shift;
    my $text = $element->content;
    $text =~ s/\\/\\\\/g;
    $text =~ s/\n/\\n/g;
    $text =~ s/\t/\\t/g;
    my $lineno = (my $copy = $parsed) =~ tr/\n//d;
    my $byteno = length $parsed;
    print join("\t", token_name($element), $text, $lineno, $byteno), "\n";
    $parsed .= $element->content;
}

sub token_name {
    my $token = shift;
    if ($token->isa('PPI::Token::Word')) {
	return $ReservedWords{$token->content} ? "keyword" :
	    $BuitinFunctions{$token->content} ? "funcall" : "word";
    } elsif (ref($token) eq 'PPI::Token::Number') {
	return $token->{_subtype} eq 'base256' ? "floating" : "integer";
    }
    $TokenMap{ref($token)} || "word";
}

BEGIN {
    %TokenMap = qw(
PPI::Token::ArrayIndex            symbol
PPI::Token::Attribute             fundef
PPI::Token::Cast                  punct
PPI::Token::Comment               text
PPI::Token::DashedWord            punct
PPI::Token::Data                  text
PPI::Token::End                   punct
PPI::Token::HereDoc               text
PPI::Token::Label                 word
PPI::Token::Magic                 punct
PPI::Token::Number                *
PPI::Token::Operator              punct
PPI::Token::Pod                   text
PPI::Token::Prototype             punct
PPI::Token::Quote::Double         string
PPI::Token::Quote::Interpolate    string
PPI::Token::Quote::Literal        string
PPI::Token::Quote::Single         string
PPI::Token::QuoteLike::Backtick   string
PPI::Token::QuoteLike::Command    string
PPI::Token::QuoteLike::Readline   string
PPI::Token::QuoteLike::Regexp     string
PPI::Token::QuoteLike::Words      string
PPI::Token::Regexp::Match         word
PPI::Token::Regexp::Substitute    word
PPI::Token::Regexp::Transliterate word
PPI::Token::Separator             punct
PPI::Token::Structure             punct
PPI::Token::Symbol                symbol
PPI::Token::Unknown               punct
PPI::Token::Whitespace            punct
PPI::Token::Word                  *
);

    # borrowed from Apache::PrettyPerl
    %ReservedWords = map { $_ => 1 } qw(
	while until for foreach unless if elsif else do
	package use no require import and or eq ne cmp
    );
    %BuitinFunctions = map { $_ => 1 } qw(
	abs accept alarm atan2 bind binmode bless
	caller chdir chmod chomp chop chown chr
	chroot close closedir connect continue cos
	crypt dbmclose dbmopen defined delete die
	dump each endgrent endhostent endnetent
	endprotoent endpwent endservent eof eval
	exec exists exit exp fcntl fileno flock
	fork format formline getc getgrent getgrgid
	getgrnam gethostbyaddr gethostbyname gethostent
	getlogin getnetbyaddr getnetbyname getnetent
	getpeername getpgrp getppid getpriority
	getprotobyname getprotobynumber getprotoent
	getpwent getpwnam getpwuid getservbyname
	getservbyport getservent getsockname
	getsockopt glob gmtime goto grep hex index
	int ioctl join keys kill last lc lcfirst
	length link listen local localtime log
	lstat map map mkdir msgctl msgget msgrcv
	msgsnd my next oct open opendir ord our pack
	pipe pop pos print printf prototype push
	quotemeta rand read readdir readline
	readlink readpipe recv redo ref rename
	reset return reverse rewinddir rindex
	rmdir scalar seek seekdir select semctl
	semget semop send setgrent sethostent
	setnetent setpgrp setpriority setprotoent
	setpwent setservent setsockopt shift shmctl
	shmget shmread shmwrite shutdown sin sleep
	socket socketpair sort splice split sprintf
	sqrt srand stat study sub substr symlink
	syscall sysopen sysread sysread sysseek
	system syswrite tell telldir tie tied
	time times truncate uc ucfirst umask undef
	unlink unpack unshift untie utime values
	vec wait waitpid wantarray warn write
    );
}

=begin lexer

use PPI::Lexer;

my $lexer = PPI::Lexer->new;
my $doc = $lexer->lex_source($code);

for my $elem ($doc->children) {
    dump_it($elem);
}

sub dump_it {
    my $element = shift;
    if ($element->isa('PPI::Token')) {
	dump_element($element);
    } elsif ($element->isa('PPI::Statement')) {
	for my $elem ($element->children) {
	    dump_it($elem);
	}
    } elsif ($element->isa('PPI::Structure')) {
	dump_element($element->start);
	for my $elem ($element->children) {
	    dump_it($elem);
	}
	dump_element($element->finish);
    } else {
	die "no match $element";
    }
}

=end lexer
