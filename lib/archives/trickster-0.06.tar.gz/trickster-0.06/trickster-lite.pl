#!/usr/local/bin/perl -w
# $Id: trickster-lite.pl,v 1.30 2003/01/15 04:26:28 miyagawa Exp $

use strict;

use POE qw(Component::Server::TCP Filter::HTTPD Filter::Stream Component::TSTP);
use Data::Properties;

# DEBUG
use Data::Dumper;
$Data::Dumper::Indent = 1;

my $Debug = 0;

# $Config: global configuration
my $conf_path = _find_config();
my $Config = TricksterLite::Config->new($conf_path);

_check_installation($Config);
_make_pid_file($Config, $$);

# for Ctrl-Z
POE::Component::TSTP->create;

# streamer: watching directory and put it into streamer
TricksterLite::Streamer->create;

# server: HTTP streaming server
TricksterLite::Server->create;

# listeners directory
TricksterLite::Listener->cleanup;

$poe_kernel->run;

END {
    if ($Config) {
	my $base_dir = $Config->get('base_directory');
	unlink "$base_dir/logs/trickster-lite.pid";
    }
}

sub _find_config {
    my @cand = (
	$ENV{TRICKSTER_LITE_CONF},
	"$ENV{HOME}/.trickster-lite.conf",
	'trickster-lite.conf',
    );
    for my $file (@cand) {
	return $file if $file && -e $file;
    }
    return;
}

sub _check_installation {
    my $config = shift;
    my $base_dir = $config->get('base_directory');
    for my $dir ( qw(listeners queue queue/history logs) ) {
	unless (-e "$base_dir/$dir" && -d _) {
	    mkdir "$base_dir/$dir", 0755 or die $!;
	}
    }
}

sub _make_pid_file {
    my($config, $pid) = @_;
    my $base_dir = $config->get('base_directory');
    my $fh = FileHandle->new("> $base_dir/logs/trickster-lite.pid") or die $!;
    $fh->print($pid, "\n");
}

#--------------------------------------------------

package TricksterLite::Streamer;
use POE;
use DirHandle;
use FileHandle;
use File::Copy;
use Time::HiRes qw(gettimeofday);

sub create {
    POE::Session->create(
	package_states =>
	    [ 'TricksterLite::Streamer' => [ qw(_start start_stream stream) ] ],
    );
}

sub _start {
    my($kernel, $heap, $dir) = @_[KERNEL, HEAP, ARG0];
    $kernel->alias_set('streamer');
    $kernel->yield('start_stream');
}

sub start_stream {
    my($kernel, $heap) = @_[KERNEL, HEAP];

    my $next_song = _next_song() || $Config->get('default_sound');
    warn "playing $next_song" if $Debug;

    my $media = TricksterLite::MediaFile->new($next_song);
    if ($media) {
	# set start time & file
	$heap->{time} = gettimeofday;
	$heap->{current} = $media;
	$kernel->yield('stream');
    } else {
	# Oops, file not found
	my $dir = $Config->get('base_directory');
	unlink "$dir/queue/now_playing";
	$kernel->yield('start_stream');
    }
}

sub _next_song {
    my $dir = $Config->get('base_directory') . '/queue';
    warn "directory is $dir" if $Debug;
    my $dh = DirHandle->new($dir) or return;
    my @files = sort { -M $b <=> -M $a } grep -f, map "$dir/$_", $dh->read;
    if (@files) {
	# slurp file path
	my $in = FileHandle->new($files[0]) or die "can't open $files[0]";
	chomp(my $song_path = <$in>);
	$in->close;

	# rename to "now_playing" file
	rename $files[0], "$dir/now_playing" or die "now_playing: $!";
	return $song_path;
    }
    return;
}

sub stream {
    my($kernel, $heap) = @_[KERNEL, HEAP];
    my $dir = $Config->get('base_directory') . '/queue';

    if (-e "$dir/now_playing.skip") {
	warn "force skipped!" if $Debug;
	_push_history($dir, "now_playing.skip");
	return $kernel->yield('start_stream');
    }

    my $media = $heap->{current};
    my $bytes_read = $media->fh->sysread(
	my $buffer = '', $Config->get('buffer_size'),
    ) or do {
	warn "no bytes left, skip to next song" if $Debug;
	_push_history($dir, "now_playing") if -e "$dir/now_playing";
	return $kernel->yield('start_stream');
    };

    my $delay = $media->delay_for($bytes_read);
    warn "delay is $delay for $bytes_read" if $Debug;
    _send_buffer($kernel, $heap, $buffer);
    $heap->{time} += $delay;
    warn "set alarm to $heap->{time}" if $Debug;
    $kernel->alarm_add(stream => $heap->{time});
}

sub _send_buffer {
    my($kernel, $heap, $buffer) = @_;
    my $media = $heap->{current};

    for my $listener (TricksterLite::Listener->retrieve_all) {
        my $meta_embed_buffer = _embed_icy_metadata($listener, $heap, $buffer);
        $kernel->post($listener->session_id => send_stream => $meta_embed_buffer);
    }
}

sub _embed_icy_metadata {
    my($listener, $heap, $buffer) = @_;
    my $media = $heap->{current};
    my $since_metadata = $listener->since_metadata;

    if (! $listener->is_shout || (length($buffer) + $since_metadata) < 8192) {
        $listener->since_metadata($since_metadata + length $buffer);
        return $buffer;
    }

    # Embed Metadata
    my $info = ($media->artist && $media->title) ?
	sprintf('%s - %s', $media->artist, $media->title) : $media->basename;
    my $client_info = $listener->metadata_value;

    my $bytes_left = 8192 - $since_metadata;
    my $metadata = $client_info && $client_info eq $info
	? "\0" : do {
	    warn "now send $info" if $Debug;
	    $listener->metadata_value($info); # set
	    my $meta_body = "StreamTitle='$info';\0";
	    my $meta_len  = (1 + int(length($meta_body) / 16)) * 16;
	    my $meta_head = pack 'C', int($meta_len / 16);
	    my $pad_len   = $meta_len - length($meta_body);
	    $meta_head. $meta_body. ("\0" x $pad_len);
	};

    warn "metadata length is ", length($metadata) if $Debug;
    # embed icy metadata to stream
    my $buff_head = substr $buffer, 0, $bytes_left;
    my $buff_tail = substr $buffer, $bytes_left;
    $listener->since_metadata(length $buff_tail);
    return $buff_head. $metadata. $buff_tail;
}

sub _push_history {
    my($dir, $file) = @_;
    my $hist_dir = "$dir/history";
    mkdir $hist_dir, 0755 unless -d $hist_dir;
    my $timestamp = gettimeofday;
    rename "$dir/$file", "$dir/history/$timestamp" or die "rename to $timestamp failed";
}

#--------------------------------------------------

package TricksterLite::Server;
use POE;
use HTTP::Response;

sub create {
    POE::Component::Server::TCP->new(
	Alias    => 'server',
	Port  	 => $Config->get('streaming_port'),
	ClientFilter => 'POE::Filter::HTTPD',
	InlineStates => {
	    start_stream => \&start_stream,
	    send_stream  => \&send_stream,
	},
	ClientDisconnected => sub {
	    my $session_id = $_[SESSION]->ID;
	    warn "disconnected: $session_id" if $Debug;
	    my $listener = TricksterLite::Listener->retrieve($session_id);
	    $listener->quit if $listener;
	},
	ClientError => sub {
	    my $session_id = $_[SESSION]->ID;
	    warn "error: $session_id" if $Debug;
	    my $listener = TricksterLite::Listener->retrieve($session_id);
	    $listener->quit if $listener;
	    $_[KERNEL]->yield("shutdown");
	},
	ClientInput => sub {
	    my($kernel, $heap, $request, $session) = @_[KERNEL, HEAP, ARG0, SESSION];
	    if ($request->isa('HTTP::Response')) {
		$heap->{client}->put($request);
		my $listener = Trickster::Listener->retrieve($session->ID);
		$listener->quit if $listener;
		$kernel->yield('shutdown');
		return;
	    }

	    # The request is real and fully formed.  Create and send back
	    # headers in preparation for streaming the music.

	    my $is_shout = $request->header('Icy-Metadata');
	    my $listener = TricksterLite::Listener->create({
		session_id   => $session->ID,
		is_shout     => $is_shout,
		user_agent   => $request->header('User-Agent') || 'unknown',
		remote_addr  => $heap->{remote_ip},
		uid          => $request->uri->query,
	    });

	    my $response = HTTP::Response->new(200);
	    $response->push_header( 'Content-type' => 'audio/x-mpeg' );
	    $response->push_header( 'X-Audiocast-name' => $Config->get('castname') );
	    _push_shout_header($response) if $listener->is_shout;

	    $heap->{client}->put($response);

	    # Note that we do not shut down here.  Once the response's
	    # headers are flushed, the ClientFlushed callback will begin
	    # streaming the actual content.
	    $kernel->yield('start_stream');
	},
    );
}

sub _push_shout_header {
    my $response = shift;
    $response->push_header('Icy-Name' => $Config->get('castname'));
    $response->push_header('Icy-URL'  => $Config->get('icy_url'));
    $response->push_header('Icy-MetaInt' => '8192');
}

sub start_stream {
    my($kernel, $heap, $session) = @_[KERNEL, HEAP, SESSION];
    warn "start stream: ", $session->ID if $Debug;
    $heap->{client}->set_output_filter(POE::Filter::Stream->new);
}

sub send_stream {
    my($kernel, $heap, $session, $buffer) = @_[KERNEL, HEAP, SESSION, ARG0];
    warn "send stream: ", $session->ID if $Debug;
    unless ($heap->{client}){
	warn "client goes away! ", $session->ID if $Debug;
	$kernel->yield('shutdown');
	my $listener = TricksterLite::Listener->retrieve($session->ID);
	$listener->quit if $listener;
	return;
    }
    my $pending_bytes = $heap->{client}->get_driver_out_octets();
    if ($pending_bytes >= $Config->get('buffer_size') * 256) {
	warn "pending_bytes: ", $pending_bytes, " at ", $session->ID if $Debug;
	my $listener = TricksterLite::Listener->retrieve($session->ID);
	$listener->quit if $listener;
    }
    $heap->{client}->put($buffer);
}

#--------------------------------------------------

package TricksterLite::MediaFile;
use MP3::Info;
use File::Basename ();

sub new {
    my($class, $path) = @_;
    my $fh   = FileHandle->new($path) or return;
    my $info = get_mp3info($path) or return;
    bless {
	path => $path,
	info => $info,
	tag  => scalar get_mp3tag($path),
	fh   => $fh,
    }, $class;
}

sub path { shift->{path} }
sub info { shift->{info} }
sub tag  { shift->{tag} }
sub fh   { shift->{fh} }

sub title  { shift->{tag}->{TITLE} }
sub artist { shift->{tag}->{ARTIST} }

sub basename {
    my $self = shift;
    (my $name = File::Basename::basename($self->path)) =~ s/\.mp3$//i;
    return $name;
}

sub delay_for {
    my($self, $bytes) = @_;
    return $bytes * 8 / $self->{info}->{BITRATE} / 1000;
}

#--------------------------------------------------

package TricksterLite::Listener;
use DirHandle;
use FileHandle;

my %listeners;

sub cleanup {
    my $class = shift;
    my $dir = $Config->get('base_directory') . '/listeners';
    my $dh  = DirHandle->new($dir);
    unlink $_ for grep -f, map "$dir/$_", $dh->read;
}

sub retrieve_all {
    my $class = shift;
    return values %listeners;
}

sub retrieve {
    my($class, $sid) = @_;
    return $listeners{$sid};
}

sub create {
    my($class, $data) = @_;
    warn "registering ", join ":", %$data if $Debug;
    my $dir = $Config->get('base_directory') . '/listeners';
    my $out = FileHandle->new("> $dir/$data->{session_id}");
    $out->print(<<EOF);
Remote-Addr: $data->{remote_addr}
User-Agent: $data->{user_agent}
UID: $data->{uid}
EOF
    ;
    my $self = bless {
	%$data,
	since_metadata => 0,
	metadata_value => undef,
    }, $class;
    return $listeners{$data->{session_id}} = $self;
}

sub quit {
    my $self = shift;
    my $sid  = $self->session_id;
    my $dir = $Config->get('base_directory') . '/listeners';
    warn "unlinking $dir/$sid" if $Debug;
    unlink "$dir/$sid";
    delete $listeners{$sid};
}

sub session_id  { shift->{session_id} }
sub remote_addr { shift->{remote_addr} }
sub user_agent  { shift->{user_agent} }
sub uid         { shift->{uid} }
sub is_shout    { shift->{is_shout} }

sub since_metadata {
    my $self = shift;
    $self->{since_metadata} = shift if @_;
    $self->{since_metadata};
}

sub metadata_value {
    my $self = shift;
    $self->{metadata_value} = shift if @_;
    $self->{metadata_value};
}

#--------------------------------------------------

package TricksterLite::Config;
use base qw(Data::Properties);
use FileHandle;

sub new {
    my($class, $path) = @_;
    my $self = $class->SUPER::new;
    $self->load(FileHandle->new($path));
    return $self;
}

BEGIN {
    *get = __PACKAGE__->can('get_property');	# alias
}

__END__

=head1 NAME

trickster-lite - Pure Perl MP3 Streaming Server

=head1 INSTALL

=head2 HOW TO SET UP

copy stub C<trickster-lite.conf.sample> to anywhere your like, and
edit it. Then set C<TRICKSTER_LITE_CONF> envirionment variable to its
path.

  % cp trickster-lite.conf.sample ~/.trickster-lite.conf
  % vi ~/.trickster-lite.conf
  % setenv TRICKSTER_LITE_CONF ~/.trickster-lite.conf

=head2 HOW TO RUN

just run C<trickster-lite.pl>, which runs on foreground.

  % ./trickster-lite.pl &

=head1 USAGE

=head2 HOW TO ENQUEUE YOUR SONG

make a text file which has a path to mp3 file.

  % echo /path/to/file.mp3 > queue/blahblah

=head2 HOW DO I SEE WHAT'S PLAYING RIGHT NOW

see C<now_playing> file in C<queue> directory

  % cat queue/now_playing

=head2 HOW TO SKIP CURRNET PLAYING SONG

rename C<now_playing> file to C<now_playing.skip>

  % cd queue
  % mv now_playing now_playing.skip

=head2 HOW DO I SEE WHO'S LISTENING

listeners are stored in C<listeners> directory. filenames are session
ids used in POE.

  % cat listeners/*

=head2 HOW DO I SEE WHICH SONGS PLAYED PAST

past songs are stored on C<history> directory inside C<queue>
directory. Filenames are timestamps with milliseconds.

  % cat queue/history/*

You can freely remove these files.

=head1 AUTHOR

Tatsuhiko Miyagawa E<lt>miyagawa@bulknews.netE<gt>

This software couldn't be what it is today without patches and bug
reports from:

  Hiroyuki Oyama
  Yoshiki Kurihara
  Yoshimune Kitta
  Matt Sergeant

Neat icons for trickster-lite.cgi is made by Fujino Horinouchi.

Thanks!

=head1 LICENSE

This software is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut
