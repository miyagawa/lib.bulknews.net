package Demo;
use base qw(Class::Singleton::Reload);

sub _new_instance {
    bless {
	bar => 'baz',
	mtime => -M './t/lib/source',
    }, shift;
}

1;
