package Class::Singleton::Reload;

use strict;
use vars qw($VERSION);
$VERSION = '0.01';

use base qw(Class::Singleton Class::Data::Inheritable);
__PACKAGE__->mk_classdata('reload_source');
__PACKAGE__->mk_classdata('reload_mtime');

{
    local $^W = 0;
    *reload_source = sub {
	my $class = shift;
	unless (@_ or defined $class->_reload_source_accessor) {
	    # default is to check %INC
	    (my $pkg = $class) =~ s,::,/,g;
	    my $module = $INC{$pkg . '.pm'};
	    return $module if defined $module && -e $module;
	}
	$class->_reload_source_accessor(@_);
    };
}

sub import {
    my $class = shift;

    if (! defined $class->reload_mtime) {
	# first time
	$class->reload_mtime(-M $class->reload_source);
    } elsif ($class->reload_mtime > -M $class->reload_source) {
	# modified, try to reload
	no strict 'refs';
	my $instance = \${ "$class\::_instance" };
	$$instance = undef;
    }
}

1;
__END__

=head1 NAME

Class::Singleton::Reload - Singleton which reloads when module is modified

=head1 SYNOPSIS

  package Printer;
  use base qw(Class::Singleton::Reload);

  # reloads when Printer is modified
  my $printer = Printer->instance;

  package My::Config;
  use base qw(Class::Singleton::Reload);
  My::Config->reload_source('/path/to/config');

  # reloads when /path/to/config is modified
  my $config = My::Config->instance;

=head1 DESCRIPTION

Class::Singleton::Reload is a variety of Class::Singleton, which
reloads itself when source file is updated since its last compile
time. Might be useful in persistent environment like mod_perl.

=head1 METHODS

=over 4

=item reload_source

  Class->reload_source($file);

By default, subclass of Class::Singleton::Reload reloads itself when
the module source file (.pm) is updated. C<reload_source()> method can
be used to change this behaviour.

For example, consider C<My::Config> class which reads config
parameters from some config file. C<My::Config> reloads when the
config file is updated with the following setting.

  My::Config->reload_source('/path/to/config');

=back

=head1 CAVEATS

=over 4

=item *

Modification check is done at 'import' method. So you should not
define your own import(), and C<require SingletonClass> does not take
effect.

=item *

When reloaded, prerviously loaded singleton instance are destroyed.
(only if your code does not amke any other references to the instance)

=back

=head1 AUTHOR

Tatsuhiko Miyagawa E<lt>miyagawa@bulknews.netE<gt>

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

L<Class::Singleton>

=cut
