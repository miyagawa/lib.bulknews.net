package Log::Dispatch::IM::YahooMessenger;

use strict;
use vars qw($VERSION);
$VERSION = '0.01';

use base qw(Log::Dispatch::Output);
use fields qw(yahoo recipient_id);

require Log::Dispatch;
use Net::YahooMessenger;

sub new {
    my($proto, %params) = @_;
    my $class = ref $proto || $proto;

    my $self = do {
	no strict 'refs';
	bless [ \%{"$class\::FIELDS"} ], $class;
    };
    $self->_basic_init(%params);
    $self->_init(%params);

    return $self;
}

sub _init {
    my Log::Dispatch::IM::YahooMessenger $self = shift;
    my %params = @_;

    # constructs Yahoo Messenger handler
    my $yahoo = Net::YahooMessenger->new;
    $yahoo->id($params{id});
    $yahoo->password($params{password});
    $yahoo->login;

    $self->{yahoo} = $yahoo;
    $self->{recipient_id} = $params{recipient_id};
}

sub log_message {
    my Log::Dispatch::IM::YahooMessenger $self = shift;
    my %params = @_;
    $self->{yahoo}->send($self->{recipient_id}, $params{message});
}

1;
__END__

=head1 NAME

Log::Dispatch::IM::YahooMessenger - Logging to Yahoo! Messenger

=head1 SYNOPSIS

  use Log::Dispatch::IM::YahooMessenger;

  my $log = Log::Dispatch::IM::YahooMessenger->new(
      name         => 'yahoo',
      min_level    => 'emergency',
      id           => $yahoo_id,
      password     => $password,
      recipient_id => $recipient_yahoo_id,
  );
  $log->log(level => 'emergency', message => 'something BAD!');

=head1 DESCRIPTION

Log::Dispatch::IM::YahooMessenger is a subclass of Log::Dispatch,
which logs message to Yahoo! Messenger.

=head1 AUTHOR

Tatsuhiko Miyagawa E<lt>miyagawa@bulknews.netE<gt>

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

L<Net::YahooMessenger>, L<Log::Dispatch>

=cut
