#ifndef EBCDIC_H
#define EBCDIC_H  "$Id: ebcdic.h,v 1.9 2001/03/09 10:10:40 martin Exp $"

#include <ap_ebcdic.h>

#endif /*EBCDIC_H*/
