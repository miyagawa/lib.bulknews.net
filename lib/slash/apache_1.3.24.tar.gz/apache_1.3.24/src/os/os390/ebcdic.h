#ifndef EBCDIC_H
#define EBCDIC_H  "$Id: ebcdic.h,v 1.4 2001/03/09 10:10:45 martin Exp $"

#include <ap_ebcdic.h>

#endif /*EBCDIC_H*/
