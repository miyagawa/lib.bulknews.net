update stories set writestatus = 1;
update stories set time = now() where sid like '%17%';
